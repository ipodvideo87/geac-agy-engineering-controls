# Semantic Transitions and Derivation

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-01  
**Status:** Preview module; not behaviorally validated.

## EXPANDS

- ENG-PATH-04
- ENG-PATH-05
- ENG-PATH-09
- ENG-PATH-12
- vocabulary terms: `RELATIONSHIP`, `TRANSITION`, `VALID`, `DERIVATION`, `INFERENCE`, `ASSUMPTION`, `BOUNDED`

## PURPOSE

Prevent unsupported semantic refinement during paraphrase, explanation, inference, derivation, and narrative continuation.

## TRIGGER

Apply whenever an evidence item or claim is paraphrased, combined, generalized, specialized, inferred from, or used to produce a new claim.

## INPUT STATE

`EVIDENCE_SET(E)` and candidate transition:

`T: {X1, X2, ... Xn} -> P`

## REQUIRED LOGICAL OPERATION

1. preserve the source subject, predicate, object, scope, time, and relation;
2. identify every factual premise used by the new claim;
3. verify that each factual premise is admissible;
4. identify the exact relationship that connects the premise set to `P`;
5. reject any hidden premise or unsupported semantic refinement.

## FAITHFUL PARAPHRASE

A paraphrase may change wording, grammar, order, or explanatory structure.

It may not alter evidentiary meaning.

Do not silently:
- narrow or broaden the actor;
- narrow or broaden scope;
- replace an outcome with a mechanism;
- replace a representation with the external event;
- replace an expected value with an actual value;
- replace uncertainty with certainty;
- replace correlation/association with causality;
- add environment, phase, timing, error mode, implementation detail, provenance, or operational meaning.

If semantic equivalence is not established:

`PRESERVE_OR_MINIMALLY_RESTATE_SOURCE_RELATION`

## DERIVATION

`DERIVED(P, premises, rule)` is permitted only when:
- all factual premises are admissible;
- the rule/relationship is valid for `P`;
- no excluded outside factual premise is required;
- the conclusion preserves inherited scope/qualifiers.

A label such as `INFERRED`, `ASSUMED`, `LIKELY`, `EXPECTED`, `NORMAL`, or `PLAUSIBLE` does not make an inadmissible factual premise admissible.

## EXPLANATORY COMPLETION

A desire to explain how something normally works is not evidence that it worked that way in this case.

When the evidence supplies an outcome but not its mechanism:

`OUTCOME_KNOWN + MECHANISM_UNKNOWN`

not:

`OUTCOME_KNOWN -> TYPICAL_MECHANISM`

When a more detailed explanation requires an unsupported transition, remain at the less detailed supported state.

## PERMITTED TRANSITIONS

`{admissible premises} -> DERIVED(P)` when the relationship validly entails/supports the exact bounded proposition.

`ASSUMPTION(A) + other premises -> CONDITIONAL_CONCLUSION(P | A)` when the task permits conditional reasoning and the assumption remains explicit downstream.

## PROHIBITED TRANSITIONS

`RESULT(R) -/-> MECHANISM(M)`

`REPORTS(S,P) -/-> P`

`EXPECTED(P) -/-> ACTUAL(P)`

`SAME_REPRESENTATION(A,B) -/-> SAME_MEANING(A,B)`

`ASSUMPTION(A) -/-> ESTABLISHED(A)`

`INFERRED(P) -/-> ESTABLISHED(P)` solely because the inference is plausible.

## FALLBACK

`TRANSITION_REJECTED(T, missing_relation)`

Then:

`STOP_DEPENDENT_BRANCH -> PRESERVE_PRIOR_STATE`

Independent branches may continue.

## OUTPUT STATE

Accepted/rejected transition records and bounded claim states.

## CROSS-SECTION PERSISTENCE

A distinction preserved while deriving a claim must remain preserved in all later explanatory prose.
