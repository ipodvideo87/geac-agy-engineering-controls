# Identity, Provenance, and Time

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-01  
**Status:** Preview module; not behaviorally validated.

## EXPANDS

- ENG-PATH-03
- ENG-PATH-04
- ENG-PATH-05
- ENG-PATH-11
- vocabulary terms: `IDENTITY`, `EXACT`, `SAME_REPRESENTATION`, `SAME_BYTES`, `SAME_ARTIFACT`, `SAME_GENERATION`, `PROVENANCE`

## PURPOSE

Prevent equality, naming, location, fingerprints, present context, or temporal proximity from being silently upgraded into stronger identity or provenance relations.

## TRIGGER

Apply when reasoning uses sameness, identity, artifact lineage, generation, namespace correspondence, acquisition history, or temporal continuity.

## INPUT STATE

Evidence items/claims referring to two or more objects, representations, generations, or times.

## REQUIRED LOGICAL OPERATION

1. identify the identity dimension required by the proposition;
2. identify the exact objects being compared;
3. identify the comparison/binding evidence;
4. preserve generation/time/acquisition scope;
5. reject substitutions between identity dimensions.

## IDENTITY DIMENSIONS

Keep distinct:

`SAME_REPRESENTATION(A,B)`

`SAME_BYTES(A,B,scope,time)`

`SAME_ARTIFACT(A,B)`

`SAME_GENERATION(A,B)`

`SAME_SEMANTIC_ENTITY(A,B,namespace_relation)`

These states may relate, but none is automatically interchangeable with another.

## PROHIBITED TRANSITIONS

`SAME_NAME(A,B) -/-> SAME_ARTIFACT(A,B)`

`SAME_PATH(A_t1,A_t2) -/-> SAME_BYTES(A_t1,A_t2)`

`SAME_SIZE(A,B) -/-> SAME_BYTES(A,B)`

`NEAR_TIMESTAMP(A,B) -/-> SAME_GENERATION(A,B)`

`SAME_FINGERPRINT_VALUE(A,B) -/-> SAME_SEMANTIC_ENTITY(A,B)` unless the fingerprint's identity semantics and namespace relation are established.

`SAME_NUMERIC_ID(A,B) -/-> SAME_SEMANTIC_ENTITY(A,B)` across unbound namespaces.

`KNOW_NOW(P) -/-> AVAILABLE_EARLIER(P)`

`CURRENT_LOCATION(object) -/-> ACQUISITION_PROVENANCE(object)`

## TIME / MUTATION

Evidence about an object is bound to the observed/acquired object state and time.

If the object may have changed after the evidence was acquired, claims requiring exact current identity must be revalidated.

A later successful observation does not retroactively establish what was true in an earlier state.

## PROVENANCE

Preserve provenance fields independently:

`PROVENANCE(object, source, acquisition, time, generation, scope)`

Unknown fields remain unknown.

Do not infer generation or acquisition provenance from filename, path, timestamp, current context, or expected workflow.

## FALLBACK

If the identity relation required by the proposition is missing:

`NOT_ESTABLISHED(identity_proposition, missing_identity_relation)`

Preserve any weaker equality that actually was established.

## OUTPUT STATE

Dimensioned identity/provenance states with explicit time/scope.

## CROSS-SECTION PERSISTENCE

Do not later summarize a weaker equality as "same artifact", "same generation", "same record", or "verified provenance".
