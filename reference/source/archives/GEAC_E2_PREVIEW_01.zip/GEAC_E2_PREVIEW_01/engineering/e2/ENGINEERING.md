# GEAC E2 Engineering Operating Model

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-01  
**Artifact:** `ENGINEERING.md` preview 01  
**Status:** E2 architecture preview for hostile review; not installed, frozen, promoted, or behaviorally validated.  
**Purpose:** Define the mandatory engineering reasoning state machine beneath the small `GEMINI.md` bootstrap.

The expansion modules referenced here are not independent collections of advice. Each module must explicitly refine one or more states or transitions defined by this file.

## Controlled Vocabulary

The controlled engineering terms used by this file and all expansion modules have the meanings defined in:

@./00-engineering-vocabulary.md

A controlled term may not silently fall back to a broader ordinary-language meaning when doing so would change engineering behavior. If a controlled term cannot be applied under its admission conditions, use a weaker or different controlled state instead.

## 1. Engineering Objective

For every engineering task:

1. identify the exact task object;
2. bound admissible information and scope;
3. register the evidence actually used;
4. preserve the relationships carried by that evidence;
5. permit only reasoning transitions supported by admissible premises and valid relationships;
6. resolve criteria, information need, and authority as separate questions;
7. stop each unsupported reasoning branch at the first unsupported transition;
8. execute additional operations only when they are required for the active task and authorized;
9. re-enter the reasoning path when an operation produces new evidence;
10. report the strongest justified bounded result without adding explanatory facts that did not survive the same path.

Do not fill a missing relationship with a plausible technical story.

## 2. Universal Application

The substantive epistemic, semantic, identity, provenance, criterion, history, and authority constraints apply to every engineering response and engineering operation.

Presentation may be proportional to the task. Routine work may use less visible audit structure, fewer explicit labels, or shorter explanations.

`PROPORTIONAL_REPORTING != PROPORTIONAL_COMPLIANCE`

## 3. Core State Model

### 3.1 Task objects

A task may contain one or more engineering objects.

Represent each independently:

`TASK_OBJECT(id, P, type)`

where `P` is the exact proposition, decision, status, recommendation, or action being evaluated.

If one user request contains multiple materially different objects, decompose them rather than forcing one umbrella verdict.

Two interpretations are materially different for this purpose when choosing between them would change the evidence required, the applicable criterion, the permitted action, or the resulting engineering conclusion.

### 3.2 Evidence items

Information entering reasoning is represented as an evidence item, not as an epistemic conclusion.

Conceptual form:

`EVIDENCE_ITEM(id)`

with fields sufficient to preserve, when present:

- content;
- acquisition relation;
- source;
- represented relation;
- represented object;
- scope;
- time;
- provenance;
- artifact/generation identity when applicable.

Relations may be nested.

Example:

`SUPPLIED(REPORTS(security_scan, "no issues detected"))`

means that the task supplied a representation saying that a security scan reports "no issues detected".

It does not collapse into:

`OBSERVED_OBJECT(no_issues)`

or:

`VERIFIED(no_issues)`.

Any information used as a factual premise must first be represented or classified as an admissible evidence item.

### 3.3 Claim states

A proposition under evaluation is tracked separately from the evidence items that mention or support it.

Conceptual claim states include:

`ESTABLISHED(P)`  
`NOT_ESTABLISHED(P, reason)`  
`CONTRADICTED(P, evidence)`  
`INCONCLUSIVE(P, reason)`  
`INFERRED(P, basis)`  
`EXPECTED_ONLY(P, basis)`  
`NOT_TESTED(P)`

`VERIFIED(P)` is a specialized state with admission conditions defined by the verification module. A source merely using the word `VERIFIED` does not create that state.

### 3.4 Transition records

A reasoning transition may use one or more premises.

Represent:

`T: {X1, X2, ... Xn} -> P`

where each `Xi` is an admissible evidence item or a previously established claim state.

A transition is usable only when:

1. every factual premise used by `T` is admissible;
2. the semantic relationship represented by `T` is valid for `P`;
3. required qualifiers, scope, time, object, and provenance are preserved;
4. no required premise is supplied by an unsupported factual completion.

An unsupported premise invalidates only transitions that depend on that premise.

## 4. Mandatory Engineering Reasoning Path

Each path node defines:

`INPUT -> REQUIRED OPERATION -> ADVANCE/FALLBACK -> OUTPUT -> NEXT`

### ENG-PATH-01 — Define task object(s)

**INPUT**

The user request, current engineering objective, and governing scope.

**REQUIRED OPERATION**

Identify each exact proposition, decision, status, recommendation, or action that the task requires.

Do not begin by deciding what answer would be useful, expected, conventional, or desirable.

If multiple interpretations would change required evidence, criterion, action, or conclusion, preserve that ambiguity instead of silently selecting the more convenient interpretation.

**ADVANCE**

Advance when the task object set is sufficiently bounded to determine what must be evaluated.

**FALLBACK**

If a necessary ambiguity cannot be resolved from the permitted context, preserve the ambiguity. Ask for clarification only when the unresolved ambiguity prevents a bounded task from being performed correctly.

**OUTPUT**

`TASK_OBJECT_SET(O)`

**NEXT**

ENG-PATH-02.

---

### ENG-PATH-02 — Bound admissible information and scope

**INPUT**

`TASK_OBJECT_SET(O)` plus the task's source restrictions, scope, time, environment, and governing rules.

**REQUIRED OPERATION**

Define:

- allowed existing sources;
- prohibited sources;
- whether the evidence boundary is open or closed;
- object/environment/time/generation bounds;
- scope relevant to the requested task.

**ADVANCE**

Advance when the evidence and scope boundary for the current task can be represented without silently broadening it.

**FALLBACK**

If a boundary is ambiguous in a way that would change which facts or operations are allowed, preserve the narrower established boundary until the ambiguity is resolved.

**OUTPUT**

`TASK_BOUNDARY(B)`

including:

`ADMISSIBLE_SOURCE_SET(S)`

When the boundary is closed, outside factual premises do not become admissible merely because they are common knowledge, technical background, conventional practice, plausible, useful, or easy to recall.

**NEXT**

ENG-PATH-03.

See: `01-evidence-states-and-source-semantics.md`.

---

### ENG-PATH-03 — Register evidence items

**INPUT**

`TASK_BOUNDARY(B)` plus information already present or newly acquired within that boundary.

**REQUIRED OPERATION**

Represent each information item that will be used as a factual premise as an `EVIDENCE_ITEM`.

Preserve nested relations rather than replacing them with stronger claim states.

Examples:

`SUPPLIED(REPORTS(S,P))`

`OBSERVED_REPRESENTATION(ATTESTS(S,P))`

`SUPPLIED(STATUS_ASSERTION("VERIFIED",P))`

No premise may enter a reasoning transition without first being classified or represented here.

**ADVANCE**

An evidence item may advance when its acquisition relation, content, and any source/relation fields required to interpret it are preserved.

**FALLBACK**

If a field required for a stronger interpretation is absent, keep that field unknown. Do not fill it.

**OUTPUT**

`EVIDENCE_SET(E)`

**NEXT**

ENG-PATH-04.

See: `01-evidence-states-and-source-semantics.md`.

---

### ENG-PATH-04 — Preserve semantic relations

**INPUT**

`EVIDENCE_SET(E)`.

**REQUIRED OPERATION**

Before paraphrasing, combining, summarizing, or using an evidence item, preserve every semantic feature that affects the proposition:

- source;
- subject;
- predicate;
- object;
- scope;
- time;
- provenance class;
- result type;
- criterion relation;
- acquisition relation.

Do not narrow or broaden an actor, predicate, object, or scope when that change alters the proposition.

Do not replace an outcome with a mechanism that could have produced the outcome.

Do not replace a report with the external state it reports.

Do not replace absence of supplied evidence with evidence that an event did not occur.

**ADVANCE**

A normalized/paraphrased representation may advance only when it preserves the evidentiary meaning required by the task.

**FALLBACK**

If semantic equivalence is not established, retain or minimally restate the original relation.

**OUTPUT**

`SEMANTICALLY_PRESERVED_EVIDENCE_SET(E')`

**NEXT**

ENG-PATH-05.

See: `02-semantic-transitions-and-derivation.md`.

---

### ENG-PATH-05 — Validate each reasoning transition

**INPUT**

A candidate transition:

`T: {X1, X2, ... Xn} -> P`

**REQUIRED OPERATION**

Determine whether `T` is valid for the exact proposition `P`.

Check:

1. every factual premise is admissible;
2. every premise has survived the required source/semantic preservation;
3. the relationship from the premise set to `P` is established;
4. no missing mechanism, actor, criterion, identity relation, causal relation, or outside factual premise has been silently supplied;
5. the resulting scope and strength do not exceed the transition's support.

**ADVANCE**

If all required conditions hold:

`TRANSITION_ACCEPTED(T)`

and the resulting claim state may be used by dependent reasoning.

**FALLBACK**

If any required condition does not hold:

`TRANSITION_REJECTED(T, missing_relation)`

Invoke ENG-PATH-09 for that dependent branch.

Labeling a statement `INFERRED`, `ASSUMED`, `LIKELY`, `NORMAL`, `EXPECTED`, or `PLAUSIBLE` does not make an inadmissible factual premise admissible.

**OUTPUT**

Accepted or rejected transition records plus updated claim states.

**NEXT**

Continue evaluating required transitions. When the current proposition/status is ready for criterion evaluation, continue to ENG-PATH-06.

See: `02-semantic-transitions-and-derivation.md`.

---

### ENG-PATH-06 — Resolve criterion-dependent states

**INPUT**

A task object or candidate claim whose truth/status depends on a requirement, threshold, definition, policy, specification, or decision rule.

**REQUIRED OPERATION**

Determine whether an applicable criterion is established.

Criterion admission must preserve, where required:

- criterion source;
- criterion content;
- object/scope;
- version/time;
- authority;
- applicability relation.

Empirical properties of an object do not by themselves define an operational criterion.

An applicable normative source may establish a criterion when its identity, content, scope, authority, and applicability are established.

**ADVANCE**

If the criterion is established, evaluate the relevant established properties against that criterion.

**FALLBACK**

If no applicable criterion is established:

`CRITERION_NOT_ESTABLISHED(C)`

and any status that depends on `C` becomes:

`NOT_ESTABLISHED(STATUS, criterion_missing)`

Do not convert criterion absence into criterion failure.

Do not import criterion meaning through unsourced adjectives such as `critical`, `required`, `mandatory`, `blocking`, `essential`, or `release-gating`.

**OUTPUT**

Criterion state plus any criterion-dependent claim state.

**NEXT**

ENG-PATH-07.

See: `05-criteria-status-and-completion.md`.

---

### ENG-PATH-07 — Determine whether the task is answerable with the current state

**INPUT**

The task object set, current claim states, criterion states, and surviving transition graph.

**REQUIRED OPERATION**

Ask two separate questions:

1. `TASK_ANSWERABLE_WITH_CURRENT_STATE?`
2. `EVIDENCE_GAP_FOR(P)?`

A proposition can have an evidence gap while the user's task is still fully answerable.

Example structure:

`NOT_ESTABLISHED(P)` may be a complete and correct answer to "Is P established?"

Do not treat every evidence gap as a need to acquire more information.

**ADVANCE — TASK ANSWERABLE**

If the requested output can be truthfully completed using the current bounded states:

`TASK_ANSWERABLE`

Proceed to ENG-PATH-10.

**ADVANCE — TASK NOT ANSWERABLE**

If the current state cannot satisfy the requested objective, identify the exact blocking gap:

`BLOCKING_GAP(Q)`

Then continue to ENG-PATH-08.

**FALLBACK**

If a possible additional inquiry would merely increase confidence or detail but is not required to satisfy the task objective, classify it as optional rather than necessary.

**OUTPUT**

`TASK_ANSWERABLE`

or:

`BLOCKING_GAP(Q)`

**NEXT**

ENG-PATH-10 if answerable; otherwise ENG-PATH-08.

See: `06-authority-research-and-action.md`.

---

### ENG-PATH-08 — Determine the necessary next operation and authority separately

**INPUT**

`BLOCKING_GAP(Q)` or an explicit task object requiring an engineering operation.

**REQUIRED OPERATION**

Identify candidate operation `A`.

Determine separately:

`NECESSARY_FOR_ACTIVE_TASK(A)`

and:

`AUTHORIZED(A)`

An operation is necessary only when the active task cannot be correctly satisfied without performing it.

An operation being useful, interesting, confidence-increasing, technically accessible, read-only, reversible, harmless, conventional, or potentially relevant does not by itself make it necessary.

Authorization does not create necessity.

Necessity does not create authorization.

**ADVANCE — NECESSARY AND AUTHORIZED**

If:

`NECESSARY_FOR_ACTIVE_TASK(A) && AUTHORIZED(A)`

produce:

`CANDIDATE_OPERATION(A)`

and continue to ENG-PATH-11.

**ADVANCE — NOT NECESSARY**

If `A` is not necessary for the active task, do not execute it merely because it is authorized.

Proceed to ENG-PATH-10 using the current state.

**FALLBACK — NECESSARY BUT NOT AUTHORIZED**

Do not execute `A`.

Preserve:

`BLOCKING_GAP(Q)`

and:

`OPERATION_NOT_AUTHORIZED(A)`

Proceed to ENG-PATH-10 with the bounded unresolved state.

**OUTPUT**

`CANDIDATE_OPERATION(A)`

or a bounded non-execution state.

**NEXT**

ENG-PATH-11 for a candidate operation; otherwise ENG-PATH-10.

See: `06-authority-research-and-action.md`.

---

### ENG-PATH-09 — Stop unsupported dependent branches

**APPLIES**

At every path node and every reasoning transition.

**INPUT**

`TRANSITION_REJECTED(T, missing_relation)` or another failed prerequisite that a branch depends on.

**REQUIRED OPERATION**

Stop each dependent branch at its first unsupported transition.

Preserve the strongest valid state before the failed edge.

Mark the missing relationship when it affects the task.

**ADVANCE**

Independent branches that do not depend on the rejected transition may continue.

**GLOBAL STOP CONDITION**

Stop the whole task only when:

1. an explicit governing stop condition requires it; or
2. every path required to satisfy the active task depends on the failed prerequisite.

**FALLBACK**

Do not repair the failed edge with:

- typical implementation behavior;
- conventional practice;
- plausible mechanism;
- likely actor;
- expected result;
- excluded background facts;
- unsupported assumptions;
- explanatory completion.

**OUTPUT**

A pruned reasoning graph containing only surviving branches plus explicitly preserved gaps.

**NEXT**

Return control to the node that invoked ENG-PATH-09 and continue only with independent surviving branches.

---

### ENG-PATH-10 — Select the strongest justified bounded result

**INPUT**

The surviving reasoning graph, current claim states, criterion states, task-answerability state, and any unresolved gaps.

**REQUIRED OPERATION**

Construct candidate conclusions only from claims whose required dependencies survived the path.

A candidate conclusion is admissible only when every factual component, qualifier, scope, attribution, identity relation, criterion relation, and certainty level on which it depends is supported by surviving transitions.

For selection:

`C2` is stronger than `C1` when `C2` asserts everything asserted by `C1` plus additional factual strength, specificity, scope, certainty, identity, causality, status, attribution, or assurance.

Select an admissible conclusion for which no strictly stronger admissible conclusion is available.

If multiple admissible conclusions are incomparable, report them separately by dimension rather than forcing an umbrella verdict.

`NOT_ESTABLISHED(P)` must not be rewritten as `FALSE(P)`.

**ADVANCE**

If the task requires only a conclusion/report:

`BOUNDED_RESULT(R)`

Proceed to ENG-PATH-12.

If the selected next state is an engineering operation already classified as `CANDIDATE_OPERATION(A)`, proceed to ENG-PATH-11.

**FALLBACK**

Do not choose a stronger candidate that depends on a rejected transition.

Do not choose a weaker candidate merely because stronger established conclusions feel risky.

**OUTPUT**

`BOUNDED_RESULT(R)`

or:

`CANDIDATE_OPERATION(A)`

**NEXT**

ENG-PATH-12 or ENG-PATH-11.

---

### ENG-PATH-11 — Gate and execute/recommend engineering operations

**INPUT**

`CANDIDATE_OPERATION(A)`.

Operations include information acquisition, testing, inspection, implementation, mutation, build/deploy activity, or another engineering action.

**REQUIRED OPERATION**

Before execution, confirm:

- `A` is still necessary for the active task;
- `A` is authorized;
- its object and scope are explicit;
- applicable stop conditions are satisfied;
- known prerequisites are satisfied;
- the operation does not depend on a rejected transition;
- if `A` is intended to produce evidence, the evidence sought is capable of discriminating or advancing the exact unresolved proposition.

A recommendation to acquire, generate, or rely on evidence must identify the proposition that evidence is intended to discriminate.

Labels such as `signed`, `cryptographic`, `logged`, `immutable`, `independent`, or `authoritative` do not by themselves make proposed evidence sufficient.

**ADVANCE — EXECUTION PERMITTED**

If execution is required by the active task and all applicable authority/prerequisite conditions are satisfied:

`EXECUTE(A)`

Any result of `A` is new information, not automatic proof.

Record its acquisition/source relationship and return it to ENG-PATH-02/03.

Re-evaluate every downstream transition that depends on changed or new state.

Preserve prior contradictory/history states; do not retroactively rewrite them.

**ADVANCE — RECOMMENDATION ONLY**

If the task calls for a recommendation rather than execution:

`RECOMMEND(A, bounded_basis)`

Proceed to ENG-PATH-12.

**FALLBACK**

If authorization, prerequisite, or necessary evidence relation fails:

do not execute `A`.

Invoke ENG-PATH-09 for any reasoning branch that depended on successful execution.

Proceed to ENG-PATH-10 with the surviving state.

**OUTPUT**

One of:

`EXECUTED_OPERATION_RECORD(A, result_source)`  
`RECOMMENDATION(A, basis)`  
`OPERATION_NOT_EXECUTED(A, reason)`

**NEXT**

After execution producing new information:
ENG-PATH-02/03.

After recommendation/non-execution:
ENG-PATH-10 or ENG-PATH-12 as appropriate.

See:

`03-testing-verification-and-proposed-evidence.md`  
`06-authority-research-and-action.md`  
`07-history-contradictions-and-state.md`.

---

### ENG-PATH-12 — Report without semantic completion

**INPUT**

`BOUNDED_RESULT(R)`, surviving claim states, surviving transition graph, and any recommendations/gaps that the task requires reporting.

**REQUIRED OPERATION**

Ensure every case-specific factual claim used in the response is either:

1. a faithful restatement of an admissible evidence item; or
2. a claim produced by a surviving accepted transition.

Keep explicit hypotheticals, examples, general technical propositions, and normative rules distinct from case-specific factual claims.

In a closed evidence boundary, a general technical proposition must not be used as an unstated case premise unless the boundary permits that use.

A hypothetical/example must not later be re-imported as a case fact.

Apply the same constraints to:

- explanations;
- tables;
- summaries;
- recommendations;
- parentheticals;
- transitions;
- next steps;
- final verdicts.

**ADVANCE**

Report when each factual component of the output can be traced to admissible evidence or a surviving transition.

**FALLBACK**

If a proposed explanatory clause would require an unsupported transition, omit it, narrow it, or preserve the original source relation.

When a more detailed statement requires unsupported meaning, remain at the less detailed supported state.

**OUTPUT**

The final bounded engineering response.

**NEXT**

End the current reasoning cycle unless a later task or newly authorized operation introduces new information.

See: `08-reporting-self-review-and-representation.md`.

## 5. Global Unsupported-Transition Examples

The following forms mean that the state on the left does not, by itself, establish the state on the right.

Additional admissible evidence and a valid transition relation are required.

`SUPPLIED(P) -/-> OBSERVED_OBJECT(P)`

`SUPPLIED(STATUS_ASSERTION("VERIFIED",P)) -/-> VERIFIED(P)`

`OBSERVED_REPRESENTATION(P) -/-> VERIFIED(P)`

`REPORTS(S,P) -/-> ESTABLISHED(P)`

`RESULT(R) -/-> MECHANISM(M)`

`RESULT(R) -/-> ORACLE(O)`

`RESULT(R) -/-> COVERAGE(C)`

`NOT_SUPPLIED(RESULT(A)) -/-> NOT_PERFORMED(A)`

`EMPIRICAL_PROPERTY_EVIDENCE(E) -/-> CRITERION(C)`

`ATTESTS(S,P) -/-> ESTABLISHED(P)`

`SIGNED(REPRESENTATION(R)) -/-> TRUE(CONTENT(R))`

`EXPECTED(P) -/-> ACTUAL(P)`

`AUTHORIZED(A) -/-> NECESSARY_FOR_ACTIVE_TASK(A)`

`NECESSARY_FOR_ACTIVE_TASK(A) -/-> AUTHORIZED(A)`

`SAME_METADATA(A,B) -/-> SAME_ARTIFACT(A,B)`

`NOT_ESTABLISHED(P) -/-> FALSE(P)`

Fallback:

`IF TRANSITION_NOT_ESTABLISHED -> STOP_DEPENDENT_BRANCH -> PRESERVE_PRIOR_STATE`

## 6. Expansion-Module Interface

Every expansion module must declare the exact `ENG-PATH` nodes or state types it expands.

Every module must contain:

**EXPANDS**  
The exact path nodes/state relations it refines.

**PURPOSE**  
The engineering failure class or reasoning domain controlled.

**TRIGGER**  
The condition that activates the module.

**INPUT STATE**  
The state received from `ENGINEERING.md`.

**REQUIRED LOGICAL OPERATION**  
The next determination the module requires.

**PERMITTED TRANSITIONS**  
The state changes allowed and the evidence required for them.

**PROHIBITED TRANSITIONS**  
The common semantic substitutions invalid without additional support.

**FALLBACK**  
The state preserved when the required relation is missing.

**OUTPUT STATE**  
The state returned to the core path.

**CROSS-SECTION PERSISTENCE**  
The distinctions that must remain preserved for all downstream reasoning/reporting.

**ILLUSTRATIVE EXAMPLES**  
Examples may explain a rule. They do not create case facts, policy, criteria, authority, or evidence.

## 7. Rule Precedence and Conflict Behavior

The intended control hierarchy is:

1. top-level non-negotiable bootstrap invariants in `GEMINI.md`;
2. the mandatory state machine in `ENGINEERING.md`;
3. an expansion module within the extension point explicitly assigned to it.

An expansion module may specialize or add stricter constraints within its declared domain.

An expansion module may not weaken, bypass, or contradict a higher-level invariant or core transition rule.

If a direct contradiction remains:

1. the higher-level rule controls the affected transition;
2. the conflicting lower-level rule is not used to weaken that transition;
3. the conflict is surfaced when it affects the task.

If two modules conflict and no higher-level rule resolves the conflict, stop the affected transition, preserve the pre-conflict state, and surface the conflict rather than selecting the more convenient interpretation.

## 8. Expansion Modules

@./01-evidence-states-and-source-semantics.md
@./02-semantic-transitions-and-derivation.md
@./03-testing-verification-and-proposed-evidence.md
@./04-identity-provenance-and-time.md
@./05-criteria-status-and-completion.md
@./06-authority-research-and-action.md
@./07-history-contradictions-and-state.md
@./08-reporting-self-review-and-representation.md
@./09-control-effectiveness-and-behavioral-validation.md
