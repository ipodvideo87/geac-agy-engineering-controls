# GEAC E2 Controlled Engineering Vocabulary

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-01  
**Artifact:** `00-engineering-vocabulary.md` preview 01  
**Status:** E2 architecture preview for hostile review; not installed, frozen, promoted, or behaviorally validated.  
**Purpose:** Define the controlled meanings of engineering terms used by `ENGINEERING.md` and all E2 expansion modules so that consequential behavior does not depend on ordinary-language ambiguity.

---

# 1. Vocabulary Contract

A controlled term used by E2 has one contract meaning.

A controlled definition must state:

1. **TERM** — the controlled word or symbolic state.
2. **SEMANTIC DIMENSION** — what kind of thing the term describes.
3. **DEFINITION** — the exact intended meaning.
4. **ADMISSION CONDITION** — what must be true before the term may be applied.
5. **DOES NOT MEAN** — nearby meanings that must not be silently substituted.
6. **BEHAVIORAL EFFECT** — what using the term permits, prohibits, or requires.
7. **RELATIONSHIPS** — how the term differs from or composes with other controlled terms.

A controlled term may not silently take its ordinary conversational meaning when that would alter:

- evidence strength;
- scope;
- identity;
- causality;
- provenance;
- criterion applicability;
- authority;
- necessity;
- verification;
- status;
- historical meaning;
- or the permitted next engineering action.

If a term cannot be applied under its admission condition, use a weaker or different controlled term rather than stretching the definition.

---

# 2. Foundational Meta-Terms

These terms are used throughout the engineering reasoning model and therefore must be defined before the more specialized vocabulary.

## 2.1 `PROPOSITION`

**Semantic dimension:** Reasoning object.

**Definition:**  
A proposition is a specific statement that can be evaluated under a defined scope, object, time, environment, identity relation, or criterion.

A proposition is the thing being supported, rejected, left unresolved, tested, verified, or used in a decision.

**Admission condition:**  
The statement must be bounded enough that changing its meaning would require an explicit change to one or more of:
- subject;
- predicate;
- object;
- scope;
- time;
- identity relation;
- certainty level;
- criterion;
- or authority context.

**Does not mean:**
- a vague topic;
- a desired answer;
- an engineering goal by itself;
- a source statement merely because it contains declarative text.

**Behavioral effect:**  
Reasoning transitions must target an explicit proposition rather than an unscoped impression.

---

## 2.2 `OBJECT`

**Semantic dimension:** Engineering referent.

**Definition:**  
The specific artifact, system, component, state, event, decision, operation, or proposition to which an engineering claim applies.

**Admission condition:**  
The referent must be identifiable enough that evidence can be bound to it.

**Does not mean:**
- any thing with the same name;
- any file at the same path;
- any member of the same class;
- any later or earlier generation unless that relation is established.

**Behavioral effect:**  
Evidence about one object may not silently transfer to another object.

---

## 2.3 `EXACT`

**Semantic dimension:** Scope/identity qualifier.

**Definition:**  
"Exact" means that no material component of the proposition under evaluation is intentionally generalized, substituted, or left to an unbounded equivalence relation.

For identity claims, "exact" requires the identity relation demanded by the task to be explicitly established.

**Admission condition:**  
The comparison or proposition must specify the dimension in which exactness is asserted.

**Does not mean:**
- approximately equal;
- same name;
- same type;
- same expected value;
- similar;
- sufficiently close;
- equivalent under an unstated criterion.

**Behavioral effect:**  
If the dimension of exactness is not established, do not use `EXACT` as an assurance-strengthening adjective.

---

## 2.4 `BOUNDED`

**Semantic dimension:** Scope control.

**Definition:**  
A claim is bounded when the object, relation, scope, time, environment, certainty, and criterion required to interpret the claim are limited to what the evidence and task actually support.

**Admission condition:**  
The claim must not rely on an unstated expansion beyond the surviving evidence and transition graph.

**Does not mean:**
- weak;
- vague;
- conservative by default;
- incomplete merely because it is narrower.

**Behavioral effect:**  
A bounded conclusion may be strong if its exact scope is strongly established.

---

## 2.5 `SCOPE`

**Semantic dimension:** Applicability boundary.

**Definition:**  
The set of objects, states, environments, time periods, operations, or claim dimensions to which a source, criterion, authorization, test, observation, or conclusion applies.

**Admission condition:**  
Scope must be explicitly supplied, validly derived, or preserved as unknown.

**Does not mean:**
- the largest plausible domain;
- everything related to the same project;
- every object sharing a label.

**Behavioral effect:**  
A claim may not silently expand beyond the established scope of its supporting evidence.

---

## 2.6 `SOURCE`

**Semantic dimension:** Provenance/attribution.

**Definition:**  
The identified origin from which a representation, statement, artifact, observation, criterion, or authority claim is obtained.

**Admission condition:**  
The source identity must be preserved at the granularity required by the task.

**Does not mean:**
- the actor the model assumes probably generated it;
- the underlying system state described by the source;
- an independent verifier merely because the source is separate from the model.

**Behavioral effect:**  
Source attribution may not be narrowed, broadened, or upgraded without evidence.

---

## 2.7 `EVIDENCE`

**Semantic dimension:** Epistemic input.

**Definition:**  
Information that is admissible to reasoning about a proposition because it is present within the allowed evidence boundary and has an identified relationship to the proposition.

Evidence may be direct, indirect, weak, strong, conflicting, incomplete, or non-discriminating.

**Admission condition:**  
The item must:
1. be admissible under the task boundary;
2. be represented with sufficient source/acquisition semantics;
3. have an identified relationship to the proposition for which it is being used.

**Does not mean:**
- proof;
- truth;
- verification;
- sufficiency;
- correctness;
- relevance merely by topic similarity.

**Behavioral effect:**  
Calling something `EVIDENCE` does not itself permit `ESTABLISHED(P)`.

---

## 2.8 `ADMISSIBLE`

**Semantic dimension:** Evidence-boundary status.

**Definition:**  
An item is admissible when the governing task boundary permits it to be used as a factual premise for the current reasoning task.

**Admission condition:**  
The source/item must fall within the allowed source, scope, time, object, and acquisition rules of the current task.

**Does not mean:**
- true;
- useful;
- reliable;
- authoritative;
- sufficient;
- relevant enough to establish a proposition.

**Behavioral effect:**  
Only admissible factual premises may enter an accepted reasoning transition.

---

## 2.9 `PREMISE`

**Semantic dimension:** Reasoning dependency.

**Definition:**  
A premise is a proposition or evidence item actually used as an input to a reasoning transition.

**Admission condition:**  
A factual premise must be admissible before it can support an accepted transition.

**Does not mean:**
- any nearby fact;
- any source content merely present in context;
- an assumption merely because it would help the reasoning.

**Behavioral effect:**  
Every factual premise used by a transition must be traceable to an admissible evidence item or a previously accepted claim state.

---

## 2.10 `RELATIONSHIP`

**Semantic dimension:** Semantic connection.

**Definition:**  
The explicit logical, evidentiary, identity, provenance, causal, criterion, authority, temporal, or semantic connection by which one state may support or transform into another.

**Admission condition:**  
The relationship must either:
- be established by admissible evidence;
- be a governing normative reasoning rule;
- or be a valid derivation from admissible premises.

**Does not mean:**
- association;
- plausibility;
- typical implementation;
- common practice;
- temporal proximity;
- lexical similarity.

**Behavioral effect:**  
A missing relationship blocks only reasoning branches that depend on that relationship.

---

## 2.11 `TRANSITION`

**Semantic dimension:** Reasoning operation.

**Definition:**  
A transition is a proposed transformation from one or more admissible premises or established states into a new proposition or state.

Conceptual form:

`T: {X1, X2, ... Xn} -> P`

**Admission condition:**  
All required premises must be admissible and the connecting relationship must be valid for the exact target proposition.

**Does not mean:**
- a paraphrase by default;
- a narrative continuation;
- a probable technical explanation.

**Behavioral effect:**  
If a transition is not established, the dependent branch stops at the strongest valid prior state.

---

## 2.12 `VALID`

**Semantic dimension:** Rule/transition qualification.

**Definition:**  
A transition, method, criterion application, or reasoning operation is valid when it satisfies the exact rules that govern that type of operation.

For a reasoning transition, validity requires:
- admissible premises;
- preserved semantics;
- an established connection to the target proposition;
- no unsupported factual completion.

**Admission condition:**  
The applicable validation rule must be known.

**Does not mean:**
- true;
- useful;
- approved;
- successful;
- conventional.

**Behavioral effect:**  
Do not use `VALID` without identifying what operation or rule-set the validity refers to.

---

## 2.13 `ESTABLISHED`

**Semantic dimension:** Epistemic claim state.

**Definition:**  
A proposition is established when the admissible evidence and accepted transitions are sufficient for that exact bounded proposition.

Every factual component and qualifier of the proposition must be supported by the surviving dependency graph.

**Admission condition:**  
There must be no required unsupported transition between the admissible premises and the proposition.

**Does not mean:**
- reported;
- asserted;
- expected;
- likely;
- plausible;
- verified by label;
- universally true outside the bounded proposition.

**Behavioral effect:**  
`ESTABLISHED(P)` may be reported as a factual conclusion within its exact bound.

---

## 2.14 `NOT_ESTABLISHED`

**Semantic dimension:** Epistemic claim state.

**Definition:**  
The current admissible evidence and surviving transitions do not support `ESTABLISHED(P)`.

**Admission condition:**  
At least one relationship required to establish `P` is absent, invalid, unresolved, contradicted, or outside the evidence boundary.

**Does not mean:**
- false;
- disproven;
- failed;
- absent;
- not performed;
- impossible.

**Behavioral effect:**  
Preserve the uncertainty unless a separate accepted transition establishes a stronger negative proposition.

---

## 2.15 `SUFFICIENT`

**Semantic dimension:** Evidence-to-purpose relation.

**Definition:**  
Evidence or a method is sufficient only **for a named proposition, decision, criterion, or purpose** when it satisfies all requirements needed to reach that target state.

**Admission condition:**  
The phrase must be read as:

`SUFFICIENT_FOR(E, target)`

not as an unscoped adjective.

**Does not mean:**
- generally good evidence;
- strong evidence;
- commonly accepted;
- signed;
- cryptographic;
- authoritative;
- comprehensive.

**Behavioral effect:**  
Never use `sufficient` without an explicit "for what" relation when the distinction affects engineering behavior.

---

## 2.16 `NECESSARY`

**Semantic dimension:** Task/operation dependency.

**Definition:**  
An item, condition, or operation is necessary only when the active task cannot be correctly satisfied without it.

Conceptual form:

`NECESSARY_FOR_ACTIVE_TASK(A)`

**Admission condition:**  
The active task objective and the dependency from `A` to completion of that objective must both be established.

**Does not mean:**
- useful;
- confidence-increasing;
- prudent;
- customary;
- available;
- authorized;
- interesting;
- recommended.

**Behavioral effect:**  
Optional information or actions must not be relabeled necessary.

---

## 2.17 `REQUIRED`

**Semantic dimension:** Normative dependency.

**Definition:**  
A condition or action is required when an identified applicable rule, criterion, prerequisite, or active-task dependency makes it mandatory.

**Admission condition:**  
The source of the requirement must be identifiable.

**Does not mean:**
- technically desirable;
- best practice;
- conventional;
- important;
- necessary merely in the model's judgment.

**Behavioral effect:**  
When using `required`, identify whether the requirement comes from:
- task dependency;
- applicable criterion;
- governing rule;
- explicit user instruction;
- prerequisite.

---

## 2.18 `APPLICABLE`

**Semantic dimension:** Rule/criterion binding.

**Definition:**  
A rule, criterion, specification, policy, or authority statement is applicable when its established scope, object, version/time, authority, and activation conditions bind the current task object.

**Admission condition:**  
The binding relation must be established.

**Does not mean:**
- related;
- similar;
- commonly used;
- newer;
- more authoritative in general.

**Behavioral effect:**  
A criterion may not control a verdict until its applicability is established.

---

## 2.19 `AUTHORIZED`

**Semantic dimension:** Permission state.

**Definition:**  
An operation is authorized when an established authority permits that exact operation within the relevant object, scope, time, and conditions.

Conceptual form:

`AUTHORIZED(A, authority_basis, scope)`

**Admission condition:**  
The authority basis and its scope must be established.

**Does not mean:**
- useful;
- necessary;
- reversible;
- harmless;
- read-only;
- technically possible;
- likely acceptable;
- recommended.

**Behavioral effect:**  
Authorization permits an action only within its established scope. It does not make the action necessary.

---

## 2.20 `CRITERION`

**Semantic dimension:** Decision rule.

**Definition:**  
An explicit rule, threshold, requirement, or definition used to map established properties or evidence into a status, verdict, acceptance decision, or pass/fail judgment.

**Admission condition:**  
The criterion content and applicability must be established.

**Does not mean:**
- evidence;
- engineering preference;
- prudent practice;
- commonly expected condition.

**Behavioral effect:**  
Operational status must not be derived from evidence alone when a criterion-dependent mapping is required.

---

## 2.21 `VERIFIED`

**Semantic dimension:** Specialized epistemic/verification state.

**Definition:**  
`VERIFIED(P)` means that a defined verification method evaluated the exact proposition `P` against an applicable verification criterion using identified evidence and scope.

Conceptual form:

`VERIFIED(P, method, evidence, criterion, scope)`

**Admission condition:**  
All of the following must be established:
1. exact proposition;
2. exact object/scope;
3. verification method;
4. evidence produced/observed;
5. applicable verification criterion;
6. evaluation result.

**Does not mean:**
- source says "verified";
- tests passed;
- observed;
- likely correct;
- reviewed;
- checked informally;
- independently verified.

**Behavioral effect:**  
The word `verified` must not be used as ordinary praise when the admission conditions are not satisfied.

---

## 2.22 `INDEPENDENT`

**Semantic dimension:** Separation relation.

**Definition:**  
Two checks, actors, evidence sources, or verification processes are independent only when an established separation relevant to the failure mode prevents them from sharing the dependency being tested.

Conceptual form:

`INDEPENDENT(E1, E2, failure_mode)`

**Admission condition:**  
The relevant separation must be identified and established.

**Does not mean:**
- different command;
- different run;
- different file;
- second attempt;
- separate paragraph;
- same actor repeating a check;
- different label.

**Behavioral effect:**  
Do not claim independent verification merely because two checks appear distinct.

---

## 2.23 `RELEVANT`

**Semantic dimension:** Proposition relationship.

**Definition:**  
An item is relevant to proposition `P` when there is an identified relationship by which the item could affect the evaluation of `P`.

**Admission condition:**  
The relationship to the proposition must be identifiable.

**Does not mean:**
- sufficient;
- necessary;
- admissible;
- probative;
- required;
- related by topic alone.

**Behavioral effect:**  
Relevance does not authorize acquisition or establish that the item should be used as a premise.

---

## 2.24 `MATERIAL`

**Semantic dimension:** Consequence significance.

**Definition:**  
A fact, distinction, ambiguity, contradiction, or omission is material to a task when changing or resolving it could change:
- the answer;
- the evidence required;
- the applicable criterion;
- the permitted action;
- the engineering recommendation;
- or the certainty/scope of the conclusion.

**Admission condition:**  
There must be a plausible dependency between the item and one of those outputs.

**Does not mean:**
- interesting;
- large;
- severe;
- important in general;
- worth mentioning.

**Behavioral effect:**  
If E2 uses the word `material`, this exact task-effect meaning applies.

---

## 2.25 `CONSEQUENTIAL`

**Semantic dimension:** Action/decision significance.

**Definition:**  
An action or recommendation is consequential when executing or relying on it could alter an engineering artifact, system state, release status, authority boundary, evidence state, project direction, or another non-trivial external condition.

**Admission condition:**  
The possible state change must be identified.

**Does not mean:**
- scary;
- high-risk only;
- irreversible only.

**Behavioral effect:**  
Consequentiality may increase required visible care, but substantive authority and evidence rules apply to all actions.

---

## 2.26 `ASSUMPTION`

**Semantic dimension:** Conditional reasoning input.

**Definition:**  
A proposition temporarily introduced for conditional reasoning without being treated as established fact.

**Admission condition:**  
The assumption must be explicitly identified, permitted by the task, and its downstream dependence must remain visible.

**Does not mean:**
- hidden premise;
- missing fact filled in for convenience;
- admissible evidence.

**Behavioral effect:**  
A conclusion dependent on an assumption must remain conditional on that assumption.

---

## 2.27 `INFERENCE`

**Semantic dimension:** Reasoning state.

**Definition:**  
A proposition reasoned from identified premises where the result is not being claimed as independently observed.

**Admission condition:**  
All factual premises must be admissible and the inferential relationship must be valid.

**Does not mean:**
- permission to import outside facts;
- guess;
- likely mechanism;
- established fact by label alone.

**Behavioral effect:**  
`INFERRED(P)` does not increase the admissibility of its premises.

---

## 2.28 `DERIVATION`

**Semantic dimension:** Reasoning operation.

**Definition:**  
A derivation is a reasoning transition whose conclusion follows from identified admissible premises under an explicit valid relationship.

**Admission condition:**  
Premises and relationship must be identified.

**Does not mean:**
- plausible explanation;
- narrative completion;
- unstated common knowledge.

**Behavioral effect:**  
Derived claims inherit the scope and dependency limits of their premises.

---

## 2.29 `OBSERVATION`

**Semantic dimension:** Acquisition relation.

**Definition:**  
An observation is a direct encounter with a representation or object through an identified observation method.

**Admission condition:**  
The observed thing and method must be identifiable.

**Does not mean:**
- truth of everything represented;
- verification;
- causality;
- provenance beyond what was observed.

**Behavioral effect:**  
Always bind observation to its actual object:
`OBSERVED_REPRESENTATION(R)` or `OBSERVED_OBJECT(O)`.

---

## 2.30 `REPORT`

**Semantic dimension:** Representation relation.

**Definition:**  
A report is a representation that states or records one or more propositions.

**Admission condition:**  
The representation and reported proposition must be identifiable.

**Does not mean:**
- the external event occurred;
- the source was correct;
- the result was verified;
- the report is complete.

**Behavioral effect:**  
Use `REPORTS(S,P)` unless additional evidence permits a stronger state.

---

## 2.31 `ATTESTATION`

**Semantic dimension:** Source assertion relation.

**Definition:**  
An attestation is a representation in which an identified source declares or vouches for a proposition.

**Admission condition:**  
The attesting source and proposition must be identifiable.

**Does not mean:**
- independent observation;
- proof;
- truth;
- cryptographic integrity merely by the word "attestation".

**Behavioral effect:**  
`ATTESTS(S,P) -/-> ESTABLISHED(P)` without additional evidence and valid bindings.

---

## 2.32 `PROVENANCE`

**Semantic dimension:** Origin/history relation.

**Definition:**  
Provenance is the established information describing where an item or claim came from, how it was acquired, and when relevant, its generation, identity, time, and transformation history.

**Admission condition:**  
Each provenance field must be supported individually.

**Does not mean:**
- current location;
- filename;
- path;
- source guessed from context.

**Behavioral effect:**  
Unknown provenance fields remain unknown.

---

## 2.33 `IDENTITY`

**Semantic dimension:** Sameness relation.

**Definition:**  
Identity is an established relation that two references denote the same object, artifact, generation, semantic entity, or byte sequence under the exact identity dimension required by the task.

**Admission condition:**  
The identity dimension and evidence establishing the relation must be identified.

**Does not mean:**
- equal names;
- equal sizes;
- equal timestamps;
- equal numeric identifiers across namespaces;
- similar content;
- expected equality.

**Behavioral effect:**  
Always specify the identity dimension when it affects the conclusion.

---

## 2.34 `CORRECT`

**Semantic dimension:** Proposition/behavior qualification.

**Definition:**  
A claim, result, implementation, or behavior is correct only relative to an explicitly identified proposition, specification, criterion, or required semantics.

**Admission condition:**  
The object of correctness and its standard must be established.

**Does not mean:**
- tests passed;
- completed;
- plausible;
- formatted;
- internally consistent.

**Behavioral effect:**  
Avoid unscoped `CORRECT`.

---

## 2.35 `COMPLETE`

**Semantic dimension:** Coverage/status qualifier.

**Definition:**  
Something is complete only relative to an explicitly defined dimension and completion criterion.

Examples:
- complete source inspection;
- complete required-field population;
- complete task response;
- complete behavioral coverage.

**Admission condition:**  
The dimension and criterion for completeness must be identified.

**Does not mean:**
- correct;
- verified;
- sufficient for a different dimension;
- finished in a general sense.

**Behavioral effect:**  
Avoid unscoped `COMPLETE`.

---

## 2.36 `READY`

**Semantic dimension:** Operational status.

**Definition:**  
`READY` is a criterion-dependent operational status assigned only when an applicable readiness criterion exists and the established evidence satisfies it.

**Admission condition:**  
An applicable readiness criterion plus evidence satisfying that criterion.

**Does not mean:**
- probably okay;
- tests passed;
- senior engineer approval;
- no known blockers;
- expected to work.

**Behavioral effect:**  
If no readiness criterion is established:
`READY = NOT_ESTABLISHED`.

---

## 2.37 `SAFE`

**Semantic dimension:** Operational/risk status.

**Definition:**  
`SAFE` is a criterion-dependent status whose meaning must specify the hazards, scope, conditions, and acceptable risk criterion being evaluated.

**Admission condition:**  
Applicable safety criterion plus sufficient evidence for that exact scoped status.

**Does not mean:**
- no issue was observed;
- reversible;
- read-only;
- likely harmless;
- approved by authority.

**Behavioral effect:**  
Avoid unscoped `SAFE`.

---

## 2.38 `FAIL`

**Semantic dimension:** Criterion/test outcome.

**Definition:**  
`FAIL` means an identified applicable criterion, test expectation, or prerequisite was evaluated and not satisfied.

**Admission condition:**  
The criterion/expectation and its applicability must be established.

**Does not mean:**
- unknown;
- not established;
- missing;
- incomplete evidence.

**Behavioral effect:**  
Do not use `FAIL` merely because evidence is insufficient.

---

## 2.39 `PASS`

**Semantic dimension:** Criterion/test outcome.

**Definition:**  
`PASS` means an identified applicable criterion, test expectation, or prerequisite was evaluated and satisfied within the stated scope.

**Admission condition:**  
The criterion/expectation, object, and scope must be identified.

**Does not mean:**
- overall correctness;
- readiness;
- safety;
- proof outside the evaluated proposition.

**Behavioral effect:**  
Scope every PASS.

---

## 2.40 `UNKNOWN`

**Semantic dimension:** Knowledge state.

**Definition:**  
The value, state, relationship, or proposition has not been established within the current admissible evidence and reasoning state.

**Admission condition:**  
The task requires tracking the item, and no stronger supported state exists.

**Does not mean:**
- false;
- absent;
- unknowable;
- not performed;
- irrelevant.

**Behavioral effect:**  
Unknowns remain explicit when they affect the engineering task.

---

# 3. Controlled State Vocabulary

## 3.1 Acquisition / Source States

### `SUPPLIED(X)`

**Definition:** `X` was present in the permitted task input or allowed source set.

**Does not imply:** truth, observation of external reality, verification, completeness, authority.

---

### `ACQUIRED(X, method, scope)`

**Definition:** `X` was obtained through an operation performed within the allowed scope.

**Does not imply:** the acquired content is true or sufficient.

---

### `NOT_SUPPLIED(X)`

**Definition:** `X` is absent from the allowed evidence set available to the reasoning task.

**Does not imply:** `X` does not exist or the corresponding operation did not occur.

---

## 3.2 Representation States

### `REPORTS(S,P)`

**Definition:** Source/representation `S` reports proposition `P`.

### `ASSERTS(S,P)`

**Definition:** Source `S` asserts proposition `P`.

### `ATTESTS(S,P)`

**Definition:** Source `S` attests proposition `P`.

### `STATUS_ASSERTION(label,P)`

**Definition:** A source applies status label `label` to `P`.

### `EXPECTED_VALUE(S,V)`

**Definition:** Source `S` provides `V` as expected, configured, intended, or target value.

None of these states alone establishes the represented proposition.

---

## 3.3 Observation States

### `OBSERVED_REPRESENTATION(R)`

**Definition:** The agent directly observed representation `R`.

### `OBSERVED_OBJECT(O)`

**Definition:** The agent directly observed the relevant object/state `O` through an identified method.

### `OBSERVED_RESULT(R)`

**Definition:** The agent directly observed result representation `R`.

Observation remains bound to the thing actually observed.

---

## 3.4 Claim States

### `ESTABLISHED(P,basis)`

See foundational definition of `ESTABLISHED`.

### `NOT_ESTABLISHED(P,reason)`

See foundational definition of `NOT_ESTABLISHED`.

### `INCONCLUSIVE(P,reason)`

**Definition:** Current admissible evidence cannot resolve the proposition to the level required by the task, often because evidence is conflicting or non-discriminating.

**Does not mean:** false or not established for every possible purpose.

### `CONTRADICTED(P,evidence)`

**Definition:** Admissible evidence conflicts with `P` or with a prerequisite required for `P`.

### `DERIVED(P,premises,rule)`

**Definition:** `P` was produced by an accepted derivation.

### `INFERRED(P,basis)`

**Definition:** `P` is an explicitly inferential state whose premises and limits remain visible.

### `EXPECTED_ONLY(P,basis)`

**Definition:** `P` is expected/intended/predicted but not established as actual.

### `NOT_TESTED(P)`

**Definition:** No admissible test evidence sufficient to evaluate `P` has been established for the required object/scope/time.

**Does not mean:** failed.

---

# 4. Operational / Action States

### `TASK_ANSWERABLE`

**Definition:** The requested task output can be correctly produced from the current bounded state without additional acquisition or execution.

### `EVIDENCE_GAP_FOR(P)`

**Definition:** A relationship/evidence item required to establish `P` is missing or unresolved.

**Does not imply:** the user's task is not answerable.

### `BLOCKING_GAP(Q)`

**Definition:** An unresolved question that prevents correct completion of the active task objective.

### `NECESSARY_FOR_ACTIVE_TASK(A)`

See foundational definition of `NECESSARY`.

### `AUTHORIZED(A,basis,scope)`

See foundational definition of `AUTHORIZED`.

### `CANDIDATE_OPERATION(A)`

**Definition:** A proposed operation awaiting required gates.

### `EXECUTE(A)`

**Definition:** The operation may now be performed under the established authority/scope/prerequisite state.

### `RECOMMEND(A,basis)`

**Definition:** Propose `A`; recommendation is not execution and does not itself create authority.

### `OPERATION_NOT_EXECUTED(A,reason)`

**Definition:** Within the current reasoning cycle, `A` was not executed for the stated reason.

Do not create this state merely from absence of an execution record.

---

# 5. Criterion / Verification States

### `CRITERION(C)`

See foundational definition of `CRITERION`.

### `APPLICABLE_CRITERION(C,object,scope)`

**Definition:** Criterion `C` is established as binding the stated object and scope.

### `CRITERION_NOT_ESTABLISHED(C)`

**Definition:** No applicable criterion `C` has been established for the requested status/decision.

### `CRITERION_FAILED(C,evidence)`

**Definition:** Applicable criterion `C` exists and established evidence does not satisfy it.

### `VERIFIED(P,method,evidence,criterion,scope)`

See foundational definition of `VERIFIED`.

### `INDEPENDENTLY_VERIFIED(P,verification,independence_relation)`

**Definition:** `VERIFIED(P,...)` plus an established independence relation relevant to the failure mode.

---

# 6. Identity / History States

### `SAME_REPRESENTATION(A,B)`

**Definition:** A and B are equal under the exact representation comparison performed.

### `SAME_BYTES(A,B,scope,time)`

**Definition:** The compared byte sequences are equal within the identified comparison scope/time.

### `SAME_ARTIFACT(A,B)`

**Definition:** A and B are established as the same artifact under the identity relation required by the task.

### `SAME_GENERATION(A,B)`

**Definition:** A and B are established as belonging to the same production/generation event.

### `PROVENANCE(object,source,acquisition,time,generation,scope)`

See foundational definition of `PROVENANCE`.

### `HISTORICAL_STATE(P,time,basis)`

**Definition:** A state recorded at a particular time under the evidence then available.

### `RESOLVED_CONTRADICTION(C,new_evidence)`

**Definition:** Contradiction `C` is considered resolved for the specified purpose because identified evidence discriminates the conflicting states.

Resolution does not erase the historical contradiction.

### `RECONSTRUCTED_RECORD(R,basis)`

**Definition:** A representation created after the event/state it describes.

It must not be presented as contemporaneous evidence.

---

# 7. Transition States

### `TRANSITION(T:{X1...Xn}->P)`

**Definition:** Candidate reasoning operation from identified premises to proposition `P`.

### `TRANSITION_ACCEPTED(T)`

**Definition:** The transition satisfies all applicable admission rules.

### `TRANSITION_REJECTED(T,missing_relation)`

**Definition:** A required premise or relationship is missing/invalid.

### `SURVIVING_TRANSITION_GRAPH(G)`

**Definition:** The accepted reasoning dependencies remaining after rejected dependent branches are pruned.

### `-/->`

**Definition:** "does not, by itself, establish."

Example:

`REPORTS(S,P) -/-> ESTABLISHED(P)`

This does not mean the stronger state is impossible. It means additional admissible evidence and a valid relationship are required.

---

# 8. Reporting States

### `BOUNDED_RESULT(R)`

**Definition:** A reportable result composed only of claims whose required dependencies survived the engineering reasoning path.

### `CASE_FACT`

**Definition:** A factual proposition about the current task/object.

Must trace to admissible evidence or an accepted transition.

### `GENERAL_TECHNICAL_PROPOSITION`

**Definition:** A general engineering proposition not specific to the current case.

Under a closed evidence boundary, it must not silently become a case premise unless the boundary permits that use.

### `HYPOTHETICAL`

**Definition:** A conditional or illustrative proposition explicitly not asserted as a current case fact.

### `NORMATIVE_RULE`

**Definition:** A rule governing reasoning/action.

A normative rule is not empirical evidence that an external proposition is true.

### `RECOMMENDATION`

**Definition:** A proposed next action stated with its bounded basis and unresolved assumptions.

---

# 9. Core Non-Equivalences

Unless additional admissible evidence and a valid relationship establish the stronger state:

`SUPPLIED(P) != VERIFIED(P)`

`SUPPLIED(P) != OBSERVED_OBJECT(P)`

`OBSERVED_REPRESENTATION(P) != OBSERVED_OBJECT(P)`

`REPORTS(S,P) != ESTABLISHED(P)`

`ASSERTS(S,P) != ESTABLISHED(P)`

`ATTESTS(S,P) != ESTABLISHED(P)`

`STATUS_ASSERTION("VERIFIED",P) != VERIFIED(P)`

`EXPECTED_ONLY(P) != ESTABLISHED(P)`

`NOT_SUPPLIED(P) != NOT_PERFORMED(P)`

`NOT_ESTABLISHED(P) != FALSE(P)`

`NOT_TESTED(P) != FAILED(P)`

`EVIDENCE_GAP_FOR(P) != BLOCKING_GAP(task)`

`RELEVANT(E,P) != SUFFICIENT_FOR(E,P)`

`RELEVANT(E,P) != NECESSARY_FOR_ACTIVE_TASK(acquire(E))`

`ADMISSIBLE(E) != TRUE(E)`

`ADMISSIBLE(E) != SUFFICIENT_FOR(E,P)`

`AUTHORIZED(A) != NECESSARY_FOR_ACTIVE_TASK(A)`

`NECESSARY_FOR_ACTIVE_TASK(A) != AUTHORIZED(A)`

`RECOMMEND(A) != EXECUTE(A)`

`SIGNED(REPRESENTATION(R)) != TRUE(CONTENT(R))`

`SAME_METADATA(A,B) != SAME_ARTIFACT(A,B)`

`SAME_BYTES(A,B) != SAME_GENERATION(A,B)`

`COMPLETE(X,dimension_1) != COMPLETE(X,dimension_2)`

`PASS(test_or_criterion) != CORRECT(system)`

`METHOD_COMPLIANCE != EMPIRICAL_TRUTH`

---

# 10. Definition Use Rules

## 10.1 Controlled words must remain scoped

Do not use these words unscoped when their interpretation affects engineering behavior:

- exact;
- bounded;
- admissible;
- relevant;
- sufficient;
- necessary;
- required;
- applicable;
- valid;
- established;
- verified;
- independent;
- complete;
- correct;
- ready;
- safe;
- pass;
- fail;
- authorized;
- material;
- consequential.

Prefer relational forms such as:

`SUFFICIENT_FOR(E,P)`

`NECESSARY_FOR_ACTIVE_TASK(A)`

`APPLICABLE_CRITERION(C,object,scope)`

`AUTHORIZED(A,basis,scope)`

`VERIFIED(P,method,evidence,criterion,scope)`

instead of relying on the ordinary adjective alone.

## 10.2 Definitions do not create case facts

The existence of a vocabulary definition is normative context.

It does not establish any case-specific proposition.

## 10.3 Lower-level modules may specialize, not redefine

If an expansion module introduces a specialized term:

1. identify its parent vocabulary term;
2. define the additional meaning;
3. define admission conditions;
4. preserve the parent term's exclusions;
5. do not reuse an existing controlled word with a contradictory meaning.

## 10.4 Unknown fields remain unknown

A controlled state with partially known fields does not authorize filling missing fields from plausibility.

Example:

`PROVENANCE(object, source=?, acquisition=observed, time=?, generation=?, scope=current_file)`

must retain the unknown fields until established.

## 10.5 Ordinary prose must not silently override controlled semantics

If ordinary-language wording could be mistaken for a controlled engineering state, use an explicit controlled form or qualify the sentence sufficiently to preserve the intended meaning.

For example, do not write:

"the artifact is verified"

when the actual state is only:

`SUPPLIED(STATUS_ASSERTION("VERIFIED", artifact))`.

---

# 11. Relationship to ENGINEERING.md

`ENGINEERING.md` defines the control flow.

This vocabulary defines the meaning of the states and relationships that flow through that control flow.

Conceptually:

`ENGINEERING.md = reasoning state machine`

`00-engineering-vocabulary.md = controlled semantic type system`

Every expansion module must use both.

