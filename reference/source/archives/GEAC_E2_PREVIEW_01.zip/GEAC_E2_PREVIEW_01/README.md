# GEAC E2 Preview 01

**Contract ID:** `GEAC-2026-08-15-V1.1-E2-PREVIEW-01`

This package is a **preview candidate for design review only**. It is intentionally not described as frozen, installed, promoted, or behaviorally validated.

## Why this preview exists

D2 provided a compact kernel and strong principles, but the engineering reasoning path between those principles was not explicit enough. E1 added substantially more semantic explanation at the top level, but the release-review probe still showed unsupported local semantic completion.

This preview changes the architecture rather than merely adding more top-level prose.

## Architecture

```text
GEMINI.md
  -> engineering/e2/ENGINEERING.md
       -> 00-engineering-vocabulary.md
       -> 01-evidence-states-and-source-semantics.md
       -> 02-semantic-transitions-and-derivation.md
       -> 03-testing-verification-and-proposed-evidence.md
       -> 04-identity-provenance-and-time.md
       -> 05-criteria-status-and-completion.md
       -> 06-authority-research-and-action.md
       -> 07-history-contradictions-and-state.md
       -> 08-reporting-self-review-and-representation.md
       -> 09-control-effectiveness-and-behavioral-validation.md
```

## Architectural roles

- `GEMINI.md`: small bootstrap, precedence, immutable/global invariants.
- `ENGINEERING.md`: mandatory engineering reasoning state machine.
- `00-engineering-vocabulary.md`: controlled semantic type system.
- `01`–`09`: explicit expansion modules tied to named state-machine nodes.

## Central rule

At every consequential reasoning transition:

1. identify the current state;
2. identify the exact next proposition/state;
3. identify the relationship required to move between them;
4. advance only when that relationship is established;
5. otherwise stop the dependent branch and preserve the strongest prior state.

## Important preview caveat

This package is a design synthesis from the E2 architecture work, D2/E1 top-level controls, observed D2/E1 behavioral failures, and the migration audit. It is not a byte-for-byte transformation of every D2 module.

The next step should be hostile review of the package before installation or behavioral testing.
