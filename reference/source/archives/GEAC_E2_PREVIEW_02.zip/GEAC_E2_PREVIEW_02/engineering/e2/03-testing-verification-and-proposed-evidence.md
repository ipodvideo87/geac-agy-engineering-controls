# Testing, Verification, and Proposed Evidence

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-02  
**Status:** Preview 02 module; not frozen or promoted.

## EXPANDS

- ENG-PATH-05
- ENG-PATH-10
- ENG-PATH-11
- vocabulary terms: `PASS`, `FAIL`, `NOT_TESTED`, `VERIFIED`, `INDEPENDENT`, `SUFFICIENT`

## VOCABULARY BINDING

Controlled terms used by this module are subject to the mandatory vocabulary-resolution gate in `ENGINEERING-01-CORE.md`.

## PURPOSE

Bind test results, verification claims, and proposed evidence to the exact proposition they can discriminate.

## TRIGGER

Apply when a test result, validation result, scan/analysis result, verification claim, or proposed evidence is used to support an engineering proposition.

## INPUT STATE

A result representation or proposed method `E`, plus exact proposition `P`.

## REQUIRED LOGICAL OPERATION

For a result:

1. identify exactly what result is supplied/observed;
2. identify established test/measurement semantics;
3. identify the oracle/assertion/criterion actually used;
4. identify object, environment, scope, time, and coverage when required;
5. determine whether those established semantics discriminate `P`;
6. state only the bounded support that survives.

For proposed evidence:

1. state exact proposition `P`;
2. identify what the proposed method would actually observe, compare, measure, or attest;
3. identify assumptions/bindings required to connect that output to `P`;
4. identify alternatives the method discriminates;
5. identify uncertainties that remain.

## RESULT IS NOT MECHANISM

A reported result does not supply execution mechanics.

Without additional evidence:

`TESTS_PASSED -/-> EXIT_STATUS_0`

`TESTS_PASSED -/-> ASSERTIONS_SUCCEEDED`

`TESTS_PASSED -/-> RUNNER_SUCCEEDED`

`TESTS_PASSED -/-> TARGET_WAS_EXERCISED`

`TESTS_PASSED -/-> ADEQUATE_COVERAGE`

`TESTS_PASSED -/-> SYSTEM_CORRECT`

A scan/report saying "no issues detected" remains that reported relation unless scanner semantics and the evidence-to-proposition transition are established.

## TEST-TO-PROPOSITION PATH

`RESULT(R)`
    -> `TEST_SEMANTICS_ESTABLISHED?`
    -> `DISCRIMINATES(P)?`
    -> `BOUNDED_SUPPORT_FOR(P)`

If test semantics are unknown:

`PRESERVE_RESULT_STATE`

and do not invent missing assertion/oracle, mechanism, environment, or coverage semantics.

## PASS / FAIL

`PASS` and `FAIL` require an identified expectation/criterion and scope.

`PASS(test_case) != CORRECT(system)`

`FAIL(test_case) != FALSE(unrelated_proposition)`

`NOT_TESTED(P) != FAILED(P)`

## VERIFIED

Use:

`VERIFIED(P, method, evidence, criterion, scope)`

only when all vocabulary admission conditions for `VERIFIED` are satisfied.

A source status label is not verification:

`STATUS_ASSERTION("VERIFIED",P) -/-> VERIFIED(P)`

## INDEPENDENCE

`INDEPENDENT(E1,E2,failure_mode)` requires an established separation relevant to the failure mode.

Different command, run, file, attempt, or label is not sufficient by itself.

## PROPOSED EVIDENCE

Do not call evidence sufficient merely because it is:
- signed;
- cryptographic;
- logged;
- immutable;
- independently produced;
- authoritative by label;
- difficult to forge.

Those labels describe properties that may matter only through an established relationship to the exact proposition.

`ATTESTS(S,P) -/-> ESTABLISHED(P)`

`SIGNED(REPRESENTATION(R)) -/-> TRUE(CONTENT(R))`

A proposed method should be described semantically if a closed evidence boundary does not permit importing outside domain facts about named tools/algorithms.

## FALLBACK

If established semantics do not discriminate `P`:

`NOT_ESTABLISHED(P, test_or_method_not_discriminating)`

or preserve the narrower result state.

## OUTPUT STATE

A bounded test/verification claim, or a bounded statement of what the result/method does and does not establish.

## CROSS-SECTION PERSISTENCE

A result described narrowly here must not later become correctness, readiness, safety, identity, or proof without a separate accepted transition.
