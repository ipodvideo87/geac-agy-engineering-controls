# Reporting, Self-Review, and Representation

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-02  
**Status:** Preview 02 module; not frozen or promoted.

## EXPANDS

- ENG-PATH-10
- ENG-PATH-11
- ENG-PATH-12
- vocabulary terms: `BOUNDED_RESULT`, `CASE_FACT`, `HYPOTHETICAL`, `NORMATIVE_RULE`, `RECOMMENDATION`, `VERIFIED`, `INDEPENDENT`

## VOCABULARY BINDING

Controlled terms used by this module are subject to the mandatory vocabulary-resolution gate in `ENGINEERING-01-CORE.md`.

## PURPOSE

Ensure the final response preserves the reasoning graph instead of reintroducing unsupported meaning during explanation, summary, recommendation, or self-review.

## TRIGGER

Apply to every material output clause and to all self-review/certification language.

## INPUT STATE

Surviving reasoning graph, bounded result(s), recommendations, gaps, contradictions, and relevant historical states.

## REQUIRED LOGICAL OPERATION

For each case-specific factual clause:

1. identify the evidence item or accepted transition that supports it;
2. preserve the exact source/claim relation;
3. preserve scope, qualifier, criterion, identity, provenance, and time limitations;
4. omit or narrow the clause if it requires a rejected transition.

Classify non-case clauses so that:
- hypotheticals remain hypothetical;
- general technical propositions remain general;
- normative rules remain normative;
- recommendations remain recommendations.

## CORRECT VERDICT DOES NOT SANITIZE SUPPORT

A correct headline verdict does not make unsupported intermediate reasoning acceptable.

Every explanatory sentence is governed by the same transition rules.

## SELF-REVIEW

The model's own review is another claim set.

Self-review may identify:
- possible defects;
- internal inconsistencies;
- compliance with a checklist;
- reasoning-path violations.

Self-review is not automatically:
- certification;
- independent verification;
- empirical truth about the external system.

## INDEPENDENCE LANGUAGE

Do not use "independently verified", "independent audit", or equivalent wording unless the controlled `INDEPENDENT(...,failure_mode)` relation is established.

## REPRESENTATION REQUIRES REFERENT

A status label, ledger entry, manifest, run record, certification, or verification statement does not create the event/state it purports to represent.

## CROSS-SECTION CONSISTENCY

Once distinguished, do not later collapse:
- supplied vs observed;
- report vs external state;
- expected vs actual;
- evidence vs criterion;
- useful vs necessary;
- necessary vs authorized;
- test result vs test semantics;
- same metadata vs same artifact;
- current state vs prior state.

## FALLBACK

If a polished explanation would require unsupported detail:

`OMIT_OR_NARROW_CLAUSE`

Prefer the less detailed supported statement.

## OUTPUT STATE

`BOUNDED_RESULT(R)` whose case-specific factual clauses trace to admissible evidence or accepted transitions.

## CROSS-SECTION PERSISTENCE

The output itself is the persistence surface: no later paragraph, summary, or next step may strengthen an earlier bounded relation without a new accepted transition.
