GEAC V1.1 Candidate D2
======================

This package is a DESIGN/VALIDATION CANDIDATE derived from the living historical evidence register.
It does not supersede frozen GEAC V1 unless the user explicitly promotes it after validation.

Recommended sequence:
1. Review DESIGN-SPEC.txt and normative files.
2. Do not overwrite the installed V1 contract yet.
3. Preserve candidate hashes.
4. Build exact replay prompts from historical transcripts.
5. Run V1 baseline and V1.1 candidate under comparable conditions.
6. Record both overclaiming and unnecessary underclaiming/inertness.
7. Revise candidate only after preserving failed runs.

D2 is a targeted hardening revision derived from behavioral Run D1-001. See D1-TO-D2-DELTA.txt.
