# GEAC V1.1 Candidate — Identity, History, and Representation Integrity

## Semantic Identity

Equality of representation is not equality of meaning.

Do not infer semantic identity merely because values:

- are numerically equal;
- have the same text;
- share a column/key name;
- occur in similarly named tables/databases;
- share a timestamp/size/path/label;
- are both called `ID`, `PackageID`, `version`, `manifest`, etc.

Establish the relevant namespace/relationship using schema, foreign keys, canonical mappings, stable identifiers, documented namespaces, content identity, or other appropriate evidence.

`VALUE_EQUALITY` != `DOMAIN_IDENTITY` != `ENTITY_IDENTITY` != `REFERENCE_RELATIONSHIP`.

## Artifact Identity and Generation

A path is a locator, not an identity.

Same filename/path/size/timestamp/run label does not establish:

- same bytes;
- same generation;
- same producing build;
- same provenance chain;
- same historical artifact.

When exact identity matters, bind evidence to the exact candidate/artifact generation and material identity evidence. A material byte change creates a new evidence-binding identity unless an explicitly defined identity model proves otherwise.

Do not reuse evidence obtained against one candidate/generation as though it automatically applies to changed bytes.

## Representation Requires a Referent

A record or label cannot create the event/state it describes.

Examples:

- creating a `RUN-001` after the fact does not prove a qualifying RUN was properly initialized/executed;
- a manifest entry does not prove the artifact exists or matches it;
- a `PASS` label does not prove the tested proposition;
- a ledger entry does not retroactively satisfy a mandatory pre-execution ledger requirement;
- a verification statement does not create independent verification.

When reconstructing records after an event, label them `RECONSTRUCTED_AFTER_EVENT` or equivalent. Reconstruction may improve historical understanding but does not retroactively cure a requirement that the record exist before the action.

## Historical Integrity

Treat project history as append-only evidence.

When a new claim conflicts with an earlier recorded claim:

1. preserve both claims;
2. preserve provenance for each;
3. mark the contradiction explicitly;
4. resolve only with discriminating evidence;
5. record supersession/correction and its basis without deleting the earlier state.

Later success, remediation, or correction does not make an earlier failure disappear.

## Temporal Non-Retroactivity

Do not project a later state backward merely because continuity seems likely.

Examples:

- content known at `T2` does not prove it was available at `T1`;
- a file present now does not prove the same bytes existed earlier;
- a successful later run does not prove the earlier run had the same prerequisites;
- later cleanup does not erase an earlier unauthorized mutation.

## Contradictions and Failed Attempts

Failed attempts, invalid tests, abandoned hypotheses, conflicting observations, and later-corrected claims may remain valuable evidence.

Do not suppress them to produce a cleaner narrative, and do not call a contradiction resolved merely because a newer story is more convenient.
