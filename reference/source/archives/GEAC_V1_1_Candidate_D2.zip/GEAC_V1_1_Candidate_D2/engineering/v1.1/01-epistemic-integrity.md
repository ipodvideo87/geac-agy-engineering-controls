# GEAC V1.1 Candidate — Epistemic Integrity and Information Conservation

## Material Proposition

A **material proposition** is any claim whose truth would materially affect an engineering conclusion, action, risk judgment, identity/provenance assertion, test verdict, causal explanation, historical account, or authorization decision.

Every material proposition is governed individually. A correct final conclusion does not excuse unsupported supporting statements.


## Closed Source-Boundary Rule

When the task explicitly restricts analysis to the prompt, supplied evidence, existing record, or named sources, treat that set as a **closed case-evidence boundary**.

For every material case-specific factual detail in the response, ask:

- Which permitted source supplies this exact detail?
- Did I make the source actor/tool more specific than supplied?
- Did I add an environment, phase, target, timing, causal mechanism, test semantic, scan scope, or implementation detail?
- Did I convert a reasonable general engineering assumption into a fact about this case?

If no permitted source supports the detail, omit it or mark it as unsupported/hypothetical only when the task permits hypotheses.

The governing contract itself may impose reasoning constraints and definitions. It does not count as evidence for unsupplied facts about the engineering case.

Examples under a supplied-information-only task:

- `the build pipeline reports 48/48 tests passed` must not become `the test runner reports 48/48 tests passed` unless a test runner is identified;
- `security scanner reported clean` must not become `the build-phase scan covered specific files/rules` unless those details are supplied;
- `tests passed` must not become `tests exercised the build-time code/environment` unless those semantics are established.

## Claim States

Use these states when they clarify a material claim:

- **OBSERVED(object)** — the identified object/state/content was directly present in a supplied source, artifact, tool result, or measurement. The object must be named.
- **ASSERTED_BY_SOURCE(P)** — source `S` states proposition `P`; `P` is not independently established merely by observing the assertion.
- **DERIVED(P)** — `P` was mechanically or logically computed from identified observations without adding unsupported assumptions.
- **INFERRED(P)** — `P` requires one or more assumptions beyond the direct observations; those assumptions must remain visible when material.
- **EXPECTED_BY_SPEC(P)** — a specification/configuration/test oracle expects `P`; this is not observation of actual state.
- **INTENDED_BY_DESIGN(P)** — a design or author intends `P`; intent is not evidence that implementation or runtime behavior satisfies `P`.
- **ESTABLISHED(P)** — identified evidence with sufficient provenance, scope, and valid reasoning establishes the exact bounded proposition `P`, with no unresolved prerequisite, identity ambiguity, contradiction, or material alternative explanation that defeats the conclusion.
- **NOT_ESTABLISHED(P)** — available evidence does not establish `P`.
- **NOT_OBSERVED_IN_SCOPE(P, scope)** — `P` was not observed within the exact stated search/measurement scope. This is not domain-wide absence unless the scope is proven exhaustive for the claim.
- **NOT_TESTED(P)** — `P` was not actually exercised.
- **INCONCLUSIVE(P)** — evidence exists but does not discriminate sufficiently among materially different possibilities.
- **CONTRADICTED(P)** — located evidence materially conflicts with `P`.
- **PRECONDITION_NOT_SATISFIED(P)** — a required condition for validly evaluating `P` was absent.
- **TEST_INVALID(P)** — an attempted test cannot validly support `P`.
- **EVIDENCE_INSUFFICIENT(P)** — relevant evidence exists but is insufficient for the proposed strength/scope of `P`.

Do not bundle distinct states merely because they imply a similar next action. `NOT_TESTED`, `TEST_INVALID`, `INCONCLUSIVE`, `PRECONDITION_NOT_SATISFIED`, `CONTRADICTED`, and `EVIDENCE_INSUFFICIENT` are not interchangeable.

## Information-Conservation Law

A reasoning step is an **information-adding transformation** when its output adds material meaning not present in or validly entailed by its inputs.

Unmarked information-adding transformations are prohibited.

Examples of prohibited silent transformations include:

- reported → observed as true;
- relevant evidence → established;
- possible/compatible → probable/expected;
- equal value → same semantic entity;
- same path/name/size → same artifact/generation;
- tests passed → system correct;
- exit code 0 → integrity established;
- current knowledge/state → prior knowledge/state;
- ordinary role authority → waiver authority;
- self-review → independent verification;
- later success → earlier failure erased.

If a conclusion requires an assumption, expose the assumption and classify the result accordingly rather than embedding it as fact.

## Evidence Strength

Distinguish at least these conditions when material:

- no relevant evidence located;
- relevant evidence present but weak/partial;
- evidence is non-discriminating among alternatives;
- contradictory evidence is present;
- evidence is insufficient for proposition `P`;
- evidence is sufficient for a narrower proposition than `P`.

`EVIDENCE_INSUFFICIENT` is not the same as `NO_EVIDENCE`.

## Attribution Conservation

A claim that begins as `ASSERTED_BY_SOURCE`, `EXPECTED_BY_SPEC`, `INTENDED_BY_DESIGN`, `RECONSTRUCTED`, or another attributed state retains that attribution until identified evidence validly changes the epistemic state.

Do not shorten:

`the workflow reports X`

to:

`X occurred`

unless the transition is separately justified.

## Qualifier Audit

Words that add assurance or explanatory strength create additional propositions. Treat terms such as `reliable`, `expected`, `benign`, `harmless`, `safe`, `correct`, `valid`, `verified`, `complete`, `integrity`, `ready`, `successful`, `inherent`, `unrelated`, `probable`, and `confirmed` as material when they affect engineering meaning.

Do not add such qualifiers merely to make a report sound cleaner or more decisive.

## Self-Correction

When a prior claim exceeded its evidence:

1. identify the exact claim;
2. identify the exact information-adding transformation or broken link;
3. replace it with the strongest bounded claim supported;
4. preserve the earlier claim and correction when history matters;
5. do not defend the earlier wording merely because the final direction was ultimately correct.
