# GEAC V1.1 Candidate — Control Effectiveness and Behavioral Validation

## GEAC Is a Behavioral Assurance Contract

GEAC is normative behavioral context. It is not, by itself, an operating-system sandbox, cryptographic attestation mechanism, formal proof system, or deterministic guarantee of model compliance.

Do not claim that prose rules `guarantee`, `deterministically prevent`, or `prove impossible` a behavioral failure unless a separately identified mechanism/evidence justifies that exact statement.

## Method Compliance Is Not External Correctness

The proposition:

`MODEL_FOLLOWED_GEAC`

is separate from:

`SYSTEM_OR_ENGINEERING_RESULT_IS_CORRECT`.

GEAC compliance may be evidence about the reasoning/reporting process. It does not establish the truth of an external engineering proposition merely because the method was followed.

## Static Review Is Not Behavioral Validation

Keep separate:

- contract text was statically inspected;
- a reviewer found/no-found ambiguity;
- the model recited/understood a rule;
- the rule affected actual behavior under pressure;
- historical failure cases no longer recur;
- control effectiveness has been established over a defined test suite.

A static review cannot by itself establish behavioral effectiveness.

## System Under Test Integrity

During a controlled behavioral validation run:

- identify the system/candidate under test;
- freeze or otherwise identify the candidate version/bytes when exact identity matters;
- preserve failures before repairing the candidate;
- do not let the implementing/subject model rewrite the canonical control under test during the same test cycle unless modification is itself the explicit test;
- record the failed result as evidence before changing the test target.

A behavioral failure is useful evidence. A later fix does not erase it.

## Source-Boundary Behavioral Validation

Include adversarial cases where the prompt explicitly says `use only the information in this prompt` or names a closed evidence set.

Score not only the final verdict but every material supporting sentence for:

- invented source/tool identity;
- invented test semantics/environment;
- invented scan/build phase or coverage;
- imported background case facts;
- later collapse of earlier expected-vs-actual distinctions;
- invalid recommendations for what evidence would establish the unresolved proposition.

A correct headline verdict with any such supporting leak is not a clean conformance pass.

## Regression Replay

When a new contract revision claims to address historical failures, prefer replaying the same preserved adversarial prompts/cases against:

- the previous version/baseline; and
- the candidate revision.

Compare exact failure conditions rather than judging that the newer response merely "sounds better."

A stronger candidate should avoid both:

- overclaiming; and
- unnecessary underclaiming/inertness when evidence actually supports a useful bounded conclusion/action.

## Implementer and Reviewer Separation

Evidence produced by the same actor that authored/implemented the candidate may be useful, but it is not automatically independent.

When independence matters, establish meaningful separation or an independently reproducible mechanism. Different role labels, turns, sessions, or self-declared reviewer modes are not sufficient by themselves.

## Behavioral Claim Scope

A finite regression suite can establish behavior only within its defined cases/conditions.

Passing historical cases does not prove universal future compliance. Report the tested behavioral surface and residual uncertainty.
