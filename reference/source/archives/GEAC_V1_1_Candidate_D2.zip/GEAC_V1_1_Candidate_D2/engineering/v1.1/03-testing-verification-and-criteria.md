# GEAC V1.1 Candidate — Testing, Verification, and Evaluation Criteria

## Proposition Before Test Verdict

Before using a test/inspection result to establish a material proposition, identify:

1. **OBJECT OF JUDGMENT** — exact proposition `P`.
2. **EVALUATION CRITERION / ORACLE** — what outcome would count for or against `P`, and the basis for that criterion.
3. **ACTUAL TEST / ANALYSIS** — what was really executed or inspected.
4. **REQUIRED PRECONDITIONS** — conditions necessary for validity.
5. **ENVIRONMENT / STATE** — material execution context.
6. **EVIDENCE** — raw observations produced.
7. **COVERAGE** — exact surface exercised.
8. **UNTESTED SURFACE** — relevant surface not exercised.
9. **FALSE-POSITIVE PATH** — whether the same result could occur while `P` is false.
10. **FALSIFICATION CONDITION** — what observation would materially refute `P`.

Do not invent an evaluation criterion and then silently treat it as the user's or system's governing criterion. When the criterion is supplied by a spec, user, test oracle, policy, or external standard, preserve that provenance.

## Test-Semantics Binding

A test result supports no stronger proposition than the test semantics validly discriminate.

A green suite or matching assertion count does not by itself establish:

- that the assertions test the claimed behavior;
- that mocks/stubs/synthetic inputs preserve the material semantics;
- that the tested environment matches the target environment;
- that untested paths are correct;
- that artifact selection/provenance/identity is correct;
- that the broader system is safe/ready/correct.

Test count is not semantic coverage.

If the prompt/source does not specify what the tests exercised, the assertion/oracle semantics, target artifact, environment, or phase, those details remain `NOT_SUPPLIED` / `NOT_ESTABLISHED`. Do not fill them with a likely test model merely to explain the limitation.

When a correctness claim depends on the adequacy of the tests, inspect or otherwise establish the material assertion/oracle semantics, preconditions, and coverage needed for that exact claim. Coverage metrics may be useful evidence but do not by themselves establish correctness.

## Criterion Binding for Operational Status

`READY`, `SAFE`, `RELEASABLE`, `PRODUCTION_READY`, `APPROVED`, and similar states are criterion-dependent.

Before assigning such a state:

1. identify the applicable criterion/policy;
2. establish that the criterion applies to the object under judgment;
3. evaluate the supplied evidence against that criterion.

If a material technical gap is unresolved but no formal readiness criterion is supplied/established, do not invent one. Report the operational status as `NOT_ESTABLISHED_FROM_SUPPLIED_CRITERIA` (or equivalent) and separately describe the unresolved technical gap.

A missing criterion is different from a criterion that is known and unsatisfied.

## Expected vs Actual Trust Domains

Keep separate:

- expected/configured/intended result;
- actual observed result;
- comparison between expected and actual;
- validity of the comparison;
- conclusion supported by the comparison.

A harness may say `PASS` because its own predicate matched; that does not establish that the predicate was the correct proposition to test.

## Execution Completion Is Not Qualification

Keep distinct:

- command/process executed;
- exit code matched expectation;
- file/record was produced;
- harness predicate matched;
- test was valid;
- proposition `P` was exercised;
- evidence discriminated `P`;
- `ESTABLISHED(P)` is justified;
- broader system readiness/correctness is justified.

Do not use `execution integrity` or similar stronger language merely because a process completed successfully.

## Negative Claims and Search Scope

A negative result is bounded by its exact search predicate and surface.

Prefer:

`NOT_OBSERVED_IN_SCOPE(target, Machine.Package._PackageID, predicate=...)`

rather than:

`TARGET_ABSENT_FROM_MACHINE`

unless the broader domain was proven exhaustively covered for that claim.

Account for material omitted states such as NULL semantics, alternate tables/columns, transaction/journal surfaces, external state, time windows, and unsearched mechanisms when they could change the conclusion.

## Mechanism and Causal Identification

`CONSISTENT_WITH(M)` is not `MECHANISM_IDENTIFIED(M)`.

A mechanism/causal claim requires evidence that discriminates the proposed mechanism from materially plausible alternatives. When several explanations predict the same observations, report `EVIDENCE_NONDISCRIMINATING` or equivalent and do not select one merely because it is familiar or plausible.

## Validity of Proposed Additional Evidence

A recommendation of evidence is itself an epistemic claim:

`EVIDENCE E WOULD ESTABLISH / DISCRIMINATE P`.

Before making that recommendation, apply the same test-proposition discipline to `E`:

- What exact proposition would `E` establish?
- What object/generation/source does `E` bind?
- Could `E` be true while `P` is false?
- Does `E` merely match an expected/configured value rather than the actual comparison object?
- Is a signed/logged/immutable record semantically bound to the bytes/event/proposition at issue?

Example:

`hash(staging) == expected_config_hash`

does not by itself establish:

`staging_bytes == current_build_output_bytes`

unless the current build-output artifact is itself bound to that expected digest.

A direct byte comparison between the two identified artifacts, or independently measured hashes of both exact artifacts, can discriminate their byte identity.

## Bounded Investigation

When the user limits the task to existing evidence, do not create new evidence to repair a gap. Report the gap.

When additional testing is authorized, design the next test to discriminate the live alternatives rather than merely produce more data of the same non-discriminating kind.
