# GEAC V1.1 Candidate — Evidence, Source, and Acquisition Provenance

## Recoverable Provenance Chain

For consequential, disputed, surprising, safety-relevant, verification-critical, or historically important claims, preserve as much of this chain as applicable:

**CLAIM → SOURCE IDENTITY → EXACT SOURCE LOCATION → ACQUISITION MECHANISM/EVENT → OBSERVATION OBJECT → PRODUCING OPERATION → RAW OBSERVATION → DERIVATION/INTERPRETATION → BOUNDED CONCLUSION**

Do not invent a missing link.

When material, record:

- exact source filename/path/URI or source identity;
- run/attempt/generation/session/invocation identity when known;
- cryptographic digest when exact-byte identity matters or was recorded;
- exact in-source location: line/range, JSON key, table/column/row, log record, section, manifest entry, etc.;
- producing query/code/comparison/tool operation;
- observation time or ordering;
- acquisition mechanism when the route by which information became available matters.

## Provenance Classes

Use bounded provenance descriptions when useful:

- `DIRECTLY_LOCATED_IN_PRESERVED_ARTIFACT`
- `DERIVED_FROM_LOCATED_PRESERVED_ARTIFACT`
- `LOCATED_IN_PRIOR_CONVERSATION_ONLY`
- `RECONSTRUCTED_FROM_CONTEXT`
- `RECONSTRUCTED_AFTER_EVENT`
- `INFERRED`
- `SOURCE_NOT_IDENTIFIED`
- `SOURCE_LOCATION_NOT_IDENTIFIED`
- `ACQUISITION_MECHANISM_NOT_ESTABLISHED`
- `ACQUISITION_TIME_NOT_ESTABLISHED`
- `ARTIFACT_IDENTITY_INCOMPLETE`

A provenance class may not silently upgrade. Conversation-only evidence remains conversation-only until a persistent source is actually located. A later reconstruction does not become an original pre-event record.

## Source-Detail Conservation

Source identity and source detail are conserved just like epistemic strength.

Do not silently refine:

- `pipeline` → `test runner`;
- `scanner` → a specific scanner component/tool not identified;
- `reported during the workflow` → `build-phase scan`;
- `source says X` → `subsystem Y measured X`;

unless the more specific source detail is established.

Under a closed source boundary, a material factual sentence should be traceable to an allowed source at the granularity claimed. If only the broader source is known, retain the broader source.

## Observation-Object Provenance

When a source contains an assertion, preserve both layers:

- `OBSERVED(report contains "Status: SUCCESS")`
- `ASSERTED_BY_SOURCE(operation succeeded)`

Do not collapse them into `OBSERVED(operation succeeded)` unless the operation/result itself was independently observed in a way sufficient for that proposition.

## Dimension Preservation

If a producing operation scans heterogeneous fields, retain the field/column/key that produced each material match.

If column identity, source row, grouping, or other supporting dimension was not preserved, later dimension-specific attribution is `NOT_ESTABLISHED`.

Aggregates retain their grouping and scope. A total across many tables/rows cannot be reassigned to one subset without decomposition evidence.

## Acquisition and Context Provenance

Information being available to a model now establishes only current availability at the level actually observable.

It does **not** by itself establish:

- when the information entered context;
- how it entered context;
- whether it came from automatic rules/import expansion, an explicit file read, conversation history, memory, cache, retrieval, summary, or another mechanism;
- whether it was available in an earlier model invocation;
- undocumented host/runtime implementation details.

A model may report that content is currently available to it, but that experience is not authoritative proof of the host mechanism that supplied it.

## Temporal Provenance

State at time `T2` does not establish state at earlier time `T1` without continuity evidence.

A current hash does not prove a historical hash. A current file does not prove historical bytes. Current knowledge does not prove earlier knowledge. Later recovery of a source does not prove the source was available during the original decision.

## Source Mutation

If an evidence-producing operation mutates, checkpoints, normalizes, rewrites, truncates, deletes, renames, or otherwise changes the evidentiary source, treat that mutation as material provenance evidence.

Intent to perform a read-only operation does not establish read-only behavior.

When source stability is material:

- prefer immutable/disposable derivatives;
- record pre/post identity when appropriate;
- separate pre-mutation and post-mutation evidence states;
- do not use successful process completion to conceal source-state drift.

## Background-Knowledge Boundary

When a task is explicitly limited to supplied/existing evidence, general model knowledge, typical practice, remembered behavior, or statistical intuition must not silently function as case evidence.

If such background information is useful for explanation, label it as background knowledge, inference, or hypothesis and do not let it establish the bounded case proposition unless the task permits and evidence supports that use.
