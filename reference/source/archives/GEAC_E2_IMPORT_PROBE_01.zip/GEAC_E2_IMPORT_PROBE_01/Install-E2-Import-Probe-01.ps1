$ErrorActionPreference = "Stop"

$GeminiRoot = "$env:USERPROFILE\.gemini"
$SourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Backup = Join-Path $GeminiRoot "backup-before-e2-import-probe-01-$Stamp"

if (-not (Test-Path -LiteralPath "$SourceRoot\GEMINI.md")) {
    throw "Probe source GEMINI.md missing: $SourceRoot"
}
if (-not (Test-Path -LiteralPath "$SourceRoot\engineering\e2")) {
    throw "Probe source engineering\e2 missing: $SourceRoot"
}

New-Item -ItemType Directory -Path $Backup -Force | Out-Null

if (Test-Path -LiteralPath "$GeminiRoot\GEMINI.md") {
    Copy-Item -LiteralPath "$GeminiRoot\GEMINI.md" -Destination "$Backup\GEMINI.md" -Force
}

if (Test-Path -LiteralPath "$GeminiRoot\engineering\e2") {
    Copy-Item -LiteralPath "$GeminiRoot\engineering\e2" -Destination "$Backup\e2" -Recurse -Force
}

$InstalledE2 = "$GeminiRoot\engineering\e2"

if (Test-Path -LiteralPath $InstalledE2) {
    Remove-Item -LiteralPath $InstalledE2 -Recurse -Force
}

New-Item -ItemType Directory -Path $InstalledE2 -Force | Out-Null
Copy-Item -Path "$SourceRoot\engineering\e2\*" -Destination $InstalledE2 -Recurse -Force
Copy-Item -LiteralPath "$SourceRoot\GEMINI.md" -Destination "$GeminiRoot\GEMINI.md" -Force

$Failures = @()

$A = (Get-FileHash -LiteralPath "$SourceRoot\GEMINI.md" -Algorithm SHA256).Hash
$B = (Get-FileHash -LiteralPath "$GeminiRoot\GEMINI.md" -Algorithm SHA256).Hash
if ($A -ne $B) { $Failures += "GEMINI.md"; Write-Host "FAIL GEMINI.md" -ForegroundColor Red }
if ($A -eq $B) { Write-Host "PASS GEMINI.md" -ForegroundColor Green }

$SourceFiles = Get-ChildItem -LiteralPath "$SourceRoot\engineering\e2" -File -Recurse
foreach ($SourceFile in $SourceFiles) {
    $Relative = $SourceFile.FullName.Substring("$SourceRoot\engineering\e2".Length).TrimStart("\")
    $Destination = Join-Path $InstalledE2 $Relative

    if (-not (Test-Path -LiteralPath $Destination)) {
        $Failures += $Relative
        Write-Host "MISSING $Relative" -ForegroundColor Red
        continue
    }

    $A = (Get-FileHash -LiteralPath $SourceFile.FullName -Algorithm SHA256).Hash
    $B = (Get-FileHash -LiteralPath $Destination -Algorithm SHA256).Hash

    if ($A -ne $B) { $Failures += $Relative; Write-Host "FAIL $Relative" -ForegroundColor Red }
    if ($A -eq $B) { Write-Host "PASS $Relative" -ForegroundColor Green }
}

if ($Failures.Count -gt 0) {
    throw "Probe install verification failed: $($Failures -join ', ')"
}

Write-Host ""
Write-Host "E2-IMPORT-PROBE-01 INSTALLED + VERIFIED" -ForegroundColor Green
Write-Host "RESTORE BACKUP PATH:" -ForegroundColor Green
Write-Host $Backup -ForegroundColor Yellow
Write-Host ""
Write-Host "Fresh agy prompt:" -ForegroundColor Cyan
Write-Host "E2 IMPORT PROBE REPORT" -ForegroundColor Cyan
