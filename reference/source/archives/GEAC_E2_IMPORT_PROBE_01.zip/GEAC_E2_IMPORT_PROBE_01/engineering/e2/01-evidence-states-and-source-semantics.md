# Evidence States and Source Semantics

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-02  
**Status:** Preview 02 module; not frozen or promoted.

## EXPANDS

- ENG-PATH-02
- ENG-PATH-03
- ENG-PATH-04
- vocabulary terms: `EVIDENCE`, `ADMISSIBLE`, `SOURCE`, `SUPPLIED`, `REPORTS`, `ASSERTS`, `ATTESTS`, `OBSERVATION`, `NOT_SUPPLIED`, `UNKNOWN`

## VOCABULARY BINDING

Controlled terms used by this module are subject to the mandatory vocabulary-resolution gate in `ENGINEERING-01-CORE.md`.

## PURPOSE

Prevent information from gaining a stronger source, observation, truth, provenance, or absence meaning merely because it appears in the prompt, a document, log, report, tool result, or model context.

## TRIGGER

Apply whenever factual information enters or is used by an engineering reasoning path.

## INPUT STATE

`TASK_BOUNDARY(B)` plus one or more information items.

## REQUIRED LOGICAL OPERATION

For each factual premise actually used:

1. identify how it entered the task;
2. identify the representation/source relation it carries;
3. preserve nested relations instead of collapsing them;
4. preserve unknown source/provenance fields as unknown;
5. determine whether the item is admissible for the current task.

Examples of preserved nesting:

`SUPPLIED(REPORTS(scan_1, "no issues detected"))`

`OBSERVED_REPRESENTATION(ATTESTS(source_A, P))`

`SUPPLIED(STATUS_ASSERTION("VERIFIED", artifact_A))`

## PERMITTED TRANSITIONS

`SUPPLIED(X) -> EVIDENCE_ITEM(X)` when `X` is inside the allowed task boundary.

`OBSERVED_REPRESENTATION(R) -> ESTABLISHED(representation_contains(R,P))` only for the representation property actually observed and within the observation method/scope.

A case premise may be used as a premise in the stipulated case without converting it into an independently measured external fact.

## PROHIBITED TRANSITIONS

Without additional admissible evidence:

`SUPPLIED(P) -/-> OBSERVED_OBJECT(P)`

`SUPPLIED(P) -/-> VERIFIED(P)`

`OBSERVED_REPRESENTATION(REPORTS(S,P)) -/-> OBSERVED_OBJECT(P)`

`REPORTS(S,P) -/-> ESTABLISHED(P)`

`ASSERTS(S,P) -/-> ESTABLISHED(P)`

`ATTESTS(S,P) -/-> ESTABLISHED(P)`

`NOT_SUPPLIED(P) -/-> FALSE(P)`

`NOT_SUPPLIED(result_of(A)) -/-> NOT_PERFORMED(A)`

`UNKNOWN(P) -/-> ABSENT(P)`

## CLOSED EVIDENCE BOUNDARY

When the task restricts reasoning to supplied information or named sources:

- outside factual premises are inadmissible unless the task explicitly allows them;
- no exemption exists merely because a fact is common, technical, conventional, textbook, obvious, or usually true;
- named tools, commands, mechanisms, standards, algorithms, product behavior, or environmental details must not be imported as case facts or evidentiary bridges if they are outside the allowed boundary;
- normative vocabulary and reasoning rules constrain reasoning but do not create missing case facts.

## ABSENCE SEMANTICS

Preserve these distinctions:

`NOT_SUPPLIED(X) != NOT_PERFORMED(X)`

`NO_RECORD_IN_ALLOWED_EVIDENCE != EVENT_DID_NOT_OCCUR`

`UNKNOWN(X) != ABSENT(X)`

`NOT_ESTABLISHED(P) != FALSE(P)`

If only absence from the allowed evidence is established, report absence from the allowed evidence.

## FALLBACK

If the source, acquisition relation, observation object, or provenance field required for a stronger state is not established:

`PRESERVE_CURRENT_RELATION`

and mark the missing field `UNKNOWN` when it matters to the task.

## OUTPUT STATE

`EVIDENCE_SET(E)` whose used factual premises preserve their actual acquisition/source relations.

## CROSS-SECTION PERSISTENCE

A source assertion must not become an observation or verification later in a table, summary, recommendation, or verdict.

A prompt-supplied case premise remains a supplied case premise unless a separate observation/verification occurs.
