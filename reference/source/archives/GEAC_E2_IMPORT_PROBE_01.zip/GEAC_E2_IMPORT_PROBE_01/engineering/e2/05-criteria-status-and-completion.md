# Criteria, Status, and Completion

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-02  
**Status:** Preview 02 module; not frozen or promoted.

## EXPANDS

- ENG-PATH-06
- ENG-PATH-10
- ENG-PATH-12
- vocabulary terms: `CRITERION`, `APPLICABLE`, `READY`, `SAFE`, `COMPLETE`, `CORRECT`, `PASS`, `FAIL`, `REQUIRED`

## VOCABULARY BINDING

Controlled terms used by this module are subject to the mandatory vocabulary-resolution gate in `ENGINEERING-01-CORE.md`.

## PURPOSE

Keep empirical properties separate from the criteria that map those properties into operational statuses or verdicts.

## TRIGGER

Apply whenever a response uses or evaluates a criterion-dependent status, pass/fail judgment, completeness claim, readiness/safety claim, or requirement.

## INPUT STATE

Established properties/evidence plus requested status `S`.

## REQUIRED LOGICAL OPERATION

1. identify the criterion required to evaluate `S`;
2. identify criterion source/content;
3. establish applicability to object/scope/version/time;
4. evaluate established properties against that criterion;
5. preserve criterion absence separately from criterion failure.

## CRITERION ADMISSION

A criterion is applicable only when its binding relation is established.

Topic relevance is not applicability.

Newer is not automatically applicable.

More authoritative in general is not automatically applicable to the current object.

## EMPIRICAL PROPERTY VS STATUS

`PROPERTY(P)` does not itself define:

`READY`
`SAFE`
`RELEASABLE`
`ACCEPTABLE`
`COMPLETE`
`CORRECT`

without the needed criterion/definition.

## MISSING CRITERION

If no applicable criterion is established:

`CRITERION_NOT_ESTABLISHED(C)`

and:

`STATUS_NOT_ESTABLISHED(S, criterion_missing)`

Do not convert this into `FAIL`.

## ADJECTIVE CRITERION LEAKAGE

Do not introduce unsourced policy through adjectives such as:

- critical;
- required;
- mandatory;
- blocking;
- essential;
- release-gating;
- necessary for readiness;
- sufficient for readiness.

Use these only when the applicable rule/criterion or active-task dependency establishing that meaning is identified.

## COMPLETE

`COMPLETE` must specify the dimension and criterion.

Examples of different dimensions:
- complete required-field population;
- complete source inspection;
- complete test execution;
- complete response;
- complete behavioral coverage.

Completion in one dimension does not establish correctness, verification, or completion in another dimension.

## PASS / FAIL

`PASS` and `FAIL` are scoped criterion results.

They do not automatically propagate to an umbrella system verdict.

## FALLBACK

If criterion or applicability is missing, preserve established properties and report the requested status as `NOT_ESTABLISHED` rather than inventing a policy.

## OUTPUT STATE

`APPLICABLE_CRITERION(C,object,scope)` plus bounded status result, or explicit criterion-not-established state.

## CROSS-SECTION PERSISTENCE

A response that correctly says a criterion is missing must not later smuggle the same criterion into recommendations or adjectives.
