# History, Contradictions, and State

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-02  
**Status:** Preview 02 module; not frozen or promoted.

## EXPANDS

- ENG-PATH-03
- ENG-PATH-05
- ENG-PATH-09
- ENG-PATH-10
- ENG-PATH-11
- vocabulary terms: `HISTORICAL_STATE`, `CONTRADICTED`, `RESOLVED_CONTRADICTION`, `RECONSTRUCTED_RECORD`

## VOCABULARY BINDING

Controlled terms used by this module are subject to the mandatory vocabulary-resolution gate in `ENGINEERING-01-CORE.md`.

## PURPOSE

Preserve engineering history, contradictions, temporal state, and the distinction between contemporaneous records and later reconstruction.

## TRIGGER

Apply when evidence changes over time, a failure is followed by success, a contradiction appears, a remediation occurs, a record is reconstructed, or later evidence changes a current conclusion.

## INPUT STATE

Historical/current evidence items and claim states with time/provenance where available.

## REQUIRED LOGICAL OPERATION

1. preserve each historically established state with its time and then-available basis;
2. identify contradictions explicitly;
3. determine whether new evidence actually discriminates the conflicting states;
4. distinguish remediation from explanation;
5. distinguish current state from prior state;
6. label reconstructed representations as reconstructed.

## APPEND-ONLY ENGINEERING HISTORY

Later evidence may change the current best conclusion.

It does not erase:
- earlier failure;
- earlier contradiction;
- invalid test;
- unsupported claim;
- unauthorized action;
- crossed stop condition.

## CONTRADICTION RESOLUTION

A contradiction is resolved only for a specified proposition/purpose when identified evidence discriminates the conflicting states.

"New result looks better" is not itself contradiction resolution.

A remediation result does not establish the historical cause unless cause-discriminating evidence exists.

## TEMPORAL NON-RETROACTIVITY

`TRUE_NOW(P) -/-> TRUE_EARLIER(P)`

`AVAILABLE_NOW(E) -/-> AVAILABLE_EARLIER(E)`

`REPAIRED_NOW(system) -/-> NEVER_FAILED_EARLIER(system)`

## RECONSTRUCTED RECORDS

`RECONSTRUCTED_RECORD(R,basis)` must not be presented as:
- contemporaneous execution record;
- original ledger;
- original manifest;
- evidence that the represented event happened merely because the reconstruction says it did.

Representation requires a referent.

## FALLBACK

If new evidence does not resolve the historical conflict:

`CONTRADICTION_REMAINS_EXPLICIT`

Current-state reporting may still proceed if the task permits a bounded current-state conclusion.

## OUTPUT STATE

Time-bound historical/current claim states, contradictions, and explicit resolution/reconstruction status.

## CROSS-SECTION PERSISTENCE

Do not simplify a later summary into a history that omits a relevant earlier failure or contradiction.
