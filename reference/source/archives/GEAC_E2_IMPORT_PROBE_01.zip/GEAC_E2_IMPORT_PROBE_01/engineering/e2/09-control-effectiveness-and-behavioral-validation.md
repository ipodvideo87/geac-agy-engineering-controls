# Control Effectiveness and Behavioral Validation

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-02  
**Status:** Preview 02 module; not frozen or promoted.

## EXPANDS

The engineering contract itself.

## VOCABULARY BINDING

Controlled terms used by this module are subject to the mandatory vocabulary-resolution gate in `ENGINEERING-01-CORE.md`.

## PURPOSE

Prevent static rule quality, rule presence, self-review, or isolated successful responses from being treated as proof that the engineering control system works behaviorally.

## TRIGGER

Apply when evaluating, comparing, promoting, revising, or claiming effectiveness of GEAC/E2 or another engineering-control contract.

## INPUT STATE

Exact candidate artifact identities plus controlled behavioral test evidence.

## REQUIRED LOGICAL OPERATION

Distinguish at least:

1. static semantic review;
2. structural/architecture review;
3. loading/context evidence;
4. behavioral test result;
5. repeated behavioral consistency;
6. regression coverage;
7. positive/success-case behavior;
8. unseen holdout behavior;
9. promotion criterion.

## STATIC REVIEW != BEHAVIORAL VALIDATION

A contract can be internally coherent and still fail during generation.

A model can recite a rule and still violate it later.

A self-review checklist cannot certify its own behavioral effectiveness.

## EXPERIMENTAL ISOLATION

When comparing variants:
- preserve exact candidate bytes;
- preserve exact prompts where replay is required;
- distinguish exact replay from new sanity probes;
- do not rewrite the tested candidate during the run sequence;
- preserve failed runs;
- distinguish model variance from deterministic control behavior;
- avoid revealing intended answer/failure diagnosis inside a supposedly blind behavioral probe.

## SUCCESS CASES ARE REQUIRED

A control system that prevents overclaiming by refusing or underclaiming everything is not successful engineering behavior.

Validation must include cases where:
- strong inference is justified;
- criteria are supplied and satisfied;
- action is necessary and authorized;
- exact identity evidence is adequate for the stated identity relation;
- a test genuinely discriminates the proposition.

## FAILURE HISTORY

Earlier failures remain part of the evidence record after a revision improves behavior.

A later success does not retroactively turn an earlier failed run into a pass.

## PROMOTION

Promotion requires an explicit applicable criterion.

Do not call a candidate production-ready merely because:
- static review passed;
- one behavioral test passed;
- the model says the rules are clear;
- the candidate is newer;
- the architecture appears superior.

## FALLBACK

If behavioral evidence is insufficient for a promotion claim:

`PROMOTION_STATUS = NOT_ESTABLISHED`

while preserving any narrower static/behavioral results that are established.

## OUTPUT STATE

Dimensioned control-effectiveness status with preserved run history and residual uncertainty.

## CROSS-SECTION PERSISTENCE

Do not convert "rule exists" into "rule controls behavior", or "one run passed" into "candidate is reliable in expectation".
