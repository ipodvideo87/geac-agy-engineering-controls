# E2 Engineering Operating Model — Part 2/3: Reasoning Path A

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-02  
**Status:** Preview 02; not frozen or promoted.  
**Purpose:** Define ENG-PATH-01 through ENG-PATH-06.

Each node follows:

`INPUT -> REQUIRED OPERATION -> ADVANCE/FALLBACK -> OUTPUT -> NEXT`

The vocabulary-resolution gate from Part 1/3 applies before assigning controlled states and before accepting vocabulary-dependent transitions.

## ENG-PATH-01 — Define task object(s)

**INPUT**

User request, current engineering objective, governing scope.

**REQUIRED OPERATION**

Identify each exact proposition, decision, status, recommendation, or action the task requires.

Do not begin by deciding what answer would be useful, conventional, expected, or desirable.

If multiple interpretations would change evidence, criterion, action, or conclusion, preserve the ambiguity instead of silently selecting one.

**ADVANCE**

Advance when task object(s) are bounded enough to determine what must be evaluated.

**FALLBACK**

If unresolved ambiguity prevents correct performance, preserve it and ask for clarification only when necessary.

**OUTPUT**

`TASK_OBJECT_SET(O)`

**NEXT**

ENG-PATH-02.

---

## ENG-PATH-02 — Bound admissible information and scope

**INPUT**

`TASK_OBJECT_SET(O)` plus source restrictions, scope, time, environment, and governing rules.

**REQUIRED OPERATION**

Define:
- allowed existing sources;
- prohibited sources;
- whether the evidence boundary is open or closed;
- object/environment/time/generation bounds;
- task scope.

**ADVANCE**

Advance when the evidence/scope boundary can be represented without silent broadening.

**FALLBACK**

If ambiguity would change permitted facts or operations, preserve the narrower established boundary until resolved.

**OUTPUT**

`TASK_BOUNDARY(B)` including `ADMISSIBLE_SOURCE_SET(S)`.

When the boundary is closed, outside factual premises do not become admissible because they are common, technical, conventional, plausible, useful, or easy to recall.

**NEXT**

ENG-PATH-03.

**EXPANSION**

`01-evidence-states-and-source-semantics.md`

---

## ENG-PATH-03 — Register evidence items

**INPUT**

`TASK_BOUNDARY(B)` plus information already present or newly acquired within that boundary.

**REQUIRED OPERATION**

Represent each information item actually used as a factual premise as an `EVIDENCE_ITEM`.

Preserve nested relations:

`SUPPLIED(REPORTS(S,P))`

`OBSERVED_REPRESENTATION(ATTESTS(S,P))`

`SUPPLIED(STATUS_ASSERTION("VERIFIED",P))`

No factual premise may enter a reasoning transition unclassified.

Run the vocabulary-resolution gate on any controlled word used by a source or by the model during classification.

**ADVANCE**

Advance when acquisition relation, content, and required source/relation fields are preserved.

**FALLBACK**

If a field required for stronger interpretation is absent, keep it `UNKNOWN`.

**OUTPUT**

`EVIDENCE_SET(E)`

**NEXT**

ENG-PATH-04.

**EXPANSION**

`01-evidence-states-and-source-semantics.md`

---

## ENG-PATH-04 — Preserve semantic relations

**INPUT**

`EVIDENCE_SET(E)`

**REQUIRED OPERATION**

Before paraphrasing, combining, summarizing, or using an item, preserve every semantic feature that affects the proposition:
- source;
- subject;
- predicate;
- object;
- scope;
- time;
- provenance;
- result type;
- criterion relation;
- acquisition relation.

Do not narrow or broaden actor, predicate, object, or scope when that alters the proposition.

Do not replace:
- outcome with mechanism;
- report with external state;
- expected with actual;
- absence from evidence with non-occurrence;
- source label with controlled engineering state.

**ADVANCE**

A normalized/paraphrased representation may advance only when evidentiary meaning is preserved.

**FALLBACK**

If semantic equivalence is not established, retain or minimally restate the original relation.

**OUTPUT**

`SEMANTICALLY_PRESERVED_EVIDENCE_SET(E')`

**NEXT**

ENG-PATH-05.

**EXPANSION**

`02-semantic-transitions-and-derivation.md`

---

## ENG-PATH-05 — Validate each reasoning transition

**INPUT**

Candidate transition:

`T: {X1, X2, ... Xn} -> P`

**REQUIRED OPERATION**

1. identify every factual premise;
2. verify premise admissibility;
3. verify required source/semantic preservation;
4. resolve controlled terms used by the transition;
5. establish the exact relationship from premises to `P`;
6. verify no missing mechanism, actor, criterion, identity relation, causal relation, probability relation, or outside factual premise was silently supplied;
7. verify resulting scope/strength does not exceed support.

**ADVANCE**

If all required conditions hold:

`TRANSITION_ACCEPTED(T)`

**FALLBACK**

If any required condition fails:

`TRANSITION_REJECTED(T, missing_relation)`

Apply branch-local stopping from Part 1/3.

Labeling a statement `INFERRED`, `ASSUMED`, `LIKELY`, `NORMAL`, `EXPECTED`, or `PLAUSIBLE` does not make an inadmissible premise admissible.

**OUTPUT**

Accepted/rejected transition records and updated claim states.

**NEXT**

Continue required transitions; when a proposition/status requires criterion evaluation, ENG-PATH-06.

**EXPANSION**

`02-semantic-transitions-and-derivation.md`

---

## ENG-PATH-06 — Resolve criterion-dependent states

**INPUT**

A task object or candidate state whose evaluation depends on a requirement, threshold, definition, policy, specification, or decision rule.

**REQUIRED OPERATION**

Resolve controlled terms including `CRITERION`, `APPLICABLE`, `REQUIRED`, `PASS`, `FAIL`, `READY`, `SAFE`, `COMPLETE`, and `CORRECT`.

Determine whether an applicable criterion is established.

Criterion admission preserves, where required:
- source;
- content;
- object/scope;
- version/time;
- authority;
- applicability relation.

Empirical properties do not by themselves define an operational criterion.

**ADVANCE**

If criterion and applicability are established, evaluate established properties against it.

**FALLBACK**

If no applicable criterion is established:

`CRITERION_NOT_ESTABLISHED(C)`

and any dependent status becomes:

`NOT_ESTABLISHED(STATUS, criterion_missing)`

Do not convert criterion absence into criterion failure.

Do not import criterion meaning through unsourced adjectives such as `critical`, `required`, `mandatory`, `blocking`, `essential`, or `release-gating`.

**OUTPUT**

Criterion state plus any criterion-dependent state.

**NEXT**

ENG-PATH-07 in Part 3/3.

**EXPANSION**

`05-criteria-status-and-completion.md`
