# E2 Controlled Engineering Vocabulary — Part 4/4: Identity, History, and Reporting

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-02  
**Status:** Preview 02; not frozen or promoted.

## `IDENTITY`

**Definition:** Established relation that two references denote the same object, artifact, generation, semantic entity, or byte sequence under the exact identity dimension required by task.

**Admission:** Identity dimension and evidence establishing relation identified.

**Not:** equal names, sizes, timestamps, numeric values across namespaces, similar content, expected equality.

## `SAME_REPRESENTATION(A,B)`

**Definition:** A and B are equal under an explicitly identified representation comparison.

**Not:** automatically same semantics/artifact/generation.

## `SAME_BYTES(A,B,scope,time)`

**Definition:** Compared byte sequences are equal within identified comparison scope/time.

**Not:** generation identity, provenance, transfer history, future immutability.

## `SAME_ARTIFACT(A,B)`

**Definition:** A and B are established as same engineering artifact under identity relation required by task.

## `SAME_GENERATION(A,B)`

**Definition:** A and B are bound to same production/build/generation event under an established relation.

## `PROVENANCE(object,source,acquisition,time,generation,scope)`

**Definition:** Established information describing origin, acquisition, and when relevant generation/time/transformation history.

**Admission:** Each field supported independently.

**Not:** current path/name/location or guessed workflow.

## `HISTORICAL_STATE(P,time,basis)`

**Definition:** Engineering state recorded at a particular time with then-available basis.

**Effect:** Later evidence may change current conclusion but does not silently rewrite history.

## `RESOLVED_CONTRADICTION(C,new_evidence)`

**Definition:** Contradiction `C` is resolved for specified proposition/purpose because identified evidence discriminates conflicting states.

**Not:** later result merely looks better.

**Effect:** Resolution does not erase historical contradiction.

## `RECONSTRUCTED_RECORD(R,basis)`

**Definition:** Representation created after the event/state it describes.

**Not:** contemporaneous record.

**Effect:** Must not be presented as if it existed at event time.

## `TRANSITION_ACCEPTED(T)`

**Definition:** Transition satisfies all applicable admission rules.

## `TRANSITION_REJECTED(T,missing_relation)`

**Definition:** Required premise or relationship is missing/invalid.

**Effect:** Stop dependent reasoning branch.

## `SURVIVING_TRANSITION_GRAPH(G)`

**Definition:** Accepted reasoning dependencies remaining after rejected dependent branches are pruned.

## `-/->`

**Definition:** "does not, by itself, establish."

It does not mean the stronger state is impossible; it means additional admissible evidence and a valid relationship are required.

## `BOUNDED_RESULT(R)`

**Definition:** Reportable result composed only of claims whose required dependencies survived the reasoning path.

## `CASE_FACT`

**Definition:** Factual proposition about current task/object.

**Admission:** Traceable to admissible evidence or accepted transition.

## `DERIVED_CLAIM`

**Definition:** Case-specific proposition produced by an accepted derivation.

## `GENERAL_TECHNICAL_PROPOSITION`

**Definition:** General engineering proposition not specific to current case.

**Effect:** Under closed evidence boundary, must not silently become case premise unless boundary permits.

## `HYPOTHETICAL`

**Definition:** Conditional/illustrative proposition explicitly not asserted as current case fact.

**Effect:** Must not later be re-imported as case fact.

## `NORMATIVE_RULE`

**Definition:** Rule governing reasoning/action.

**Not:** empirical evidence that external proposition is true.

## `RECOMMENDATION`

**Definition:** Proposed next action stated with bounded basis, unresolved assumptions, and authority status where relevant.

## `METHOD_COMPLIANCE`

**Definition:** Conformance of reasoning/process to an identified method/rule set.

**Not:** empirical truth or system correctness.

`METHOD_COMPLIANCE != EMPIRICAL_TRUTH`

## Identity / History Non-Equivalences

`SAME_METADATA(A,B) != SAME_ARTIFACT(A,B)`  
`SAME_BYTES(A,B) != SAME_GENERATION(A,B)`  
`CURRENT_LOCATION(object) != ACQUISITION_PROVENANCE(object)`  
`TRUE_NOW(P) != TRUE_EARLIER(P)`  
`AVAILABLE_NOW(E) != AVAILABLE_EARLIER(E)`  
`SIGNED(REPRESENTATION(R)) != TRUE(CONTENT(R))`

## Definition Use Rules

Controlled words must remain scoped when their interpretation changes engineering behavior.

Especially avoid unscoped:
- exact;
- bounded;
- admissible;
- relevant;
- sufficient;
- necessary;
- required;
- applicable;
- valid;
- established;
- verified;
- independent;
- complete;
- correct;
- ready;
- safe;
- pass;
- fail;
- authorized;
- material;
- consequential.

Prefer relational forms such as:

`SUFFICIENT_FOR(E,P)`  
`NECESSARY_FOR_ACTIVE_TASK(A)`  
`APPLICABLE_CRITERION(C,object,scope)`  
`AUTHORIZED(A,basis,scope)`  
`VERIFIED(P,method,evidence,criterion,scope)`

Definitions are normative context. They do not create case facts.

Unknown fields remain unknown.

Lower-level modules may specialize controlled terms only by identifying the parent term, added meaning, admission conditions, and preserved exclusions.

Ordinary prose, synonyms, headings, tables, bullets, and summaries may not silently override controlled semantics.
