# E2 Controlled Engineering Vocabulary — Part 3/4: Criteria, Authority, and Decision Terms

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-02  
**Status:** Preview 02; not frozen or promoted.

## `SUFFICIENT_FOR(E,target)`

**Definition:** Evidence/method `E` satisfies all requirements needed for named proposition, decision, criterion, or purpose `target`.

**Admission:** Target is explicit and all required relationships are established.

**Not:** generally strong, signed, cryptographic, authoritative, comprehensive.

**Effect:** Avoid unscoped `sufficient`.

## `NECESSARY_FOR_ACTIVE_TASK(A)`

**Definition:** Active task cannot be correctly satisfied without `A`.

**Admission:** Active objective and dependency from `A` to task completion established.

**Not:** useful, prudent, confidence-increasing, conventional, interesting, authorized.

## `REQUIRED(X,basis)`

**Definition:** `X` is mandatory because an identified applicable rule, criterion, prerequisite, explicit instruction, or active-task dependency establishes that requirement.

**Admission:** Requirement source/basis identifiable.

**Not:** desirable, best practice, important in general.

## `RELEVANT(E,P)`

**Definition:** There is an identified relationship by which `E` could affect evaluation of `P`.

**Not:** admissible, sufficient, necessary, required, probative enough by itself.

## `CRITERION(C)`

**Definition:** Explicit rule, threshold, requirement, or definition mapping established properties/evidence to status, verdict, acceptance, or pass/fail judgment.

**Admission:** Criterion content established.

**Not:** evidence, engineering preference, best practice.

## `APPLICABLE_CRITERION(C,object,scope)`

**Definition:** Criterion `C` is established as binding the stated object/scope, including version/time/authority/activation conditions where required.

**Not:** merely related, newer, commonly used, authoritative in general.

## `CRITERION_NOT_ESTABLISHED(C)`

**Definition:** No applicable criterion `C` has been established.

**Not:** criterion failed.

## `CRITERION_FAILED(C,evidence)`

**Definition:** Applicable criterion exists and established evidence does not satisfy it.

## `AUTHORIZED(A,basis,scope)`

**Definition:** Established authority permits exact operation `A` within stated object/scope/time/conditions.

**Not:** necessary, useful, harmless, read-only, reversible, technically possible, likely acceptable.

## `OPERATION_NOT_AUTHORIZED(A)`

**Definition:** Current authority does not permit executing `A`.

**Not:** technically impossible or unnecessary.

## `TASK_ANSWERABLE`

**Definition:** Requested task output can be correctly produced from current bounded state without additional acquisition/execution.

**Not:** every proposition in task is established.

## `EVIDENCE_GAP_FOR(P)`

**Definition:** Evidence/relationship required to establish `P` is missing or unresolved.

**Not:** automatically a blocking gap for current task.

## `BLOCKING_GAP(Q)`

**Definition:** Unresolved question prevents correct completion of active task objective.

## `CANDIDATE_OPERATION(A)`

**Definition:** Proposed operation awaiting necessity, authority, prerequisite, and scope gates.

## `EXECUTE(A)`

**Definition:** State permitting actual execution after required gates are satisfied.

## `RECOMMEND(A,basis)`

**Definition:** Propose operation `A` with bounded basis.

**Not:** execution or authority grant.

## `OPERATION_NOT_EXECUTED(A,reason)`

**Definition:** In current reasoning cycle, `A` was not executed for stated reason.

**Admission:** Non-execution itself is established.

**Not:** inferred merely from absence of execution record.

## `READY`

**Definition:** Criterion-dependent operational status assigned only when an applicable readiness criterion exists and established evidence satisfies it.

**Not:** probably okay, tests passed, approval by role, no known blockers, expected to work.

If no readiness criterion is established:

`READY = NOT_ESTABLISHED`

## `SAFE`

**Definition:** Criterion-dependent status whose meaning specifies hazards, scope, conditions, and acceptable-risk criterion.

**Not:** no issue observed, reversible, read-only, likely harmless.

## `PASS`

**Definition:** Identified applicable criterion/test expectation was evaluated and satisfied within stated scope.

**Not:** overall correctness/readiness/safety.

## `FAIL`

**Definition:** Identified applicable criterion/test expectation was evaluated and not satisfied.

**Not:** unknown, not established, missing evidence.

## `CORRECT`

**Definition:** Claim/result/implementation/behavior satisfies an explicitly identified proposition, specification, criterion, or required semantics.

**Admission:** Correctness object and standard established.

**Not:** tests passed, completed, plausible, internally consistent.

## `COMPLETE`

**Definition:** Complete only relative to explicitly defined dimension and completion criterion.

**Not:** correct, verified, or complete in another dimension.

## Core Decision Non-Equivalences

`RELEVANT(E,P) != SUFFICIENT_FOR(E,P)`  
`RELEVANT(E,P) != NECESSARY_FOR_ACTIVE_TASK(acquire(E))`  
`AUTHORIZED(A) != NECESSARY_FOR_ACTIVE_TASK(A)`  
`NECESSARY_FOR_ACTIVE_TASK(A) != AUTHORIZED(A)`  
`RECOMMEND(A) != EXECUTE(A)`  
`CRITERION_NOT_ESTABLISHED(C) != CRITERION_FAILED(C)`  
`PASS(test_or_criterion) != CORRECT(system)`  
`COMPLETE(X,dimension_1) != COMPLETE(X,dimension_2)`
