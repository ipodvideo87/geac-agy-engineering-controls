# E2 Controlled Engineering Vocabulary — Part 1/4: Foundations

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-02  
**Status:** Preview 02; not frozen or promoted.  
**Purpose:** Define foundational terms used by every E2 reasoning path and module.

## Vocabulary Contract

A controlled term has one E2 contract meaning.

Before a controlled term is used as an engineering state or decision predicate, its admission condition must be satisfied.

Each controlled definition identifies:
- semantic dimension;
- definition;
- admission condition;
- excluded meanings;
- behavioral effect.

A controlled term may not silently fall back to ordinary-language meaning when that would alter evidence strength, scope, identity, causality, provenance, criterion applicability, authority, necessity, verification, status, historical meaning, or permitted action.

If admission conditions are not met, use a weaker/different state.

## `PROPOSITION`

**Dimension:** Reasoning object.

**Definition:** A specific statement evaluable under defined subject, predicate, object, scope, time, environment, identity relation, certainty, criterion, or authority context.

**Admission:** Bounded enough that changing one of those elements changes the proposition.

**Not:** vague topic, desired answer, engineering goal by itself.

**Effect:** Transitions target explicit propositions.

## `OBJECT`

**Dimension:** Engineering referent.

**Definition:** Specific artifact, system, component, state, event, decision, operation, or proposition to which a claim applies.

**Admission:** Identifiable enough for evidence binding.

**Not:** anything with same name/path/type or another generation without identity evidence.

**Effect:** Evidence about one object does not silently transfer to another.

## `EXACT`

**Dimension:** Scope/identity qualifier.

**Definition:** No material component of the asserted proposition is generalized, substituted, or left under an unstated equivalence relation.

**Admission:** Exactness dimension is identified.

**Not:** similar, approximately equal, same name/type, sufficiently close.

**Effect:** Do not use `EXACT` unless the required identity/equality dimension is established.

## `BOUNDED`

**Dimension:** Scope control.

**Definition:** Claim is limited to the object, relation, scope, time, environment, certainty, and criterion actually supported.

**Admission:** No unstated expansion beyond surviving evidence/transitions.

**Not:** weak, vague, conservative by default.

**Effect:** Bounded claims may still be strong.

## `SCOPE`

**Dimension:** Applicability boundary.

**Definition:** Set of objects, states, environments, times, operations, or claim dimensions to which a source, criterion, authorization, test, observation, or conclusion applies.

**Admission:** Explicitly supplied, validly derived, or preserved unknown.

**Not:** largest plausible domain or everything related to project.

**Effect:** Claims do not silently exceed support scope.

## `SOURCE`

**Dimension:** Provenance/attribution.

**Definition:** Identified origin of a representation, statement, artifact, observation, criterion, or authority claim.

**Admission:** Preserved at granularity required by task.

**Not:** actor the model assumes generated it, underlying state described by source, independent verifier merely because separate.

**Effect:** Attribution cannot be narrowed, broadened, or upgraded without evidence.

## `EVIDENCE`

**Dimension:** Epistemic input.

**Definition:** Information admissible to reasoning about a proposition because it is within the evidence boundary and has an identified relationship to the proposition.

**Admission:** Item is admissible, source/acquisition semantics are preserved, and relationship to target proposition is identified.

**Not:** proof, truth, verification, sufficiency, correctness.

**Effect:** `EVIDENCE(E) -/-> ESTABLISHED(P)` without a valid transition.

## `ADMISSIBLE`

**Dimension:** Evidence-boundary status.

**Definition:** Item is permitted by the task boundary to be used as a factual premise.

**Admission:** Falls within allowed source, scope, time, object, and acquisition rules.

**Not:** true, useful, reliable, authoritative, sufficient.

**Effect:** Only admissible factual premises may enter accepted transitions.

## `PREMISE`

**Dimension:** Reasoning dependency.

**Definition:** Evidence item or proposition actually used as input to a reasoning transition.

**Admission:** Factual premise is admissible.

**Not:** any nearby/context fact or convenient assumption.

**Effect:** Every factual premise must be traceable.

## `RELATIONSHIP`

**Dimension:** Semantic connection.

**Definition:** Explicit logical, evidentiary, identity, provenance, causal, criterion, authority, temporal, or semantic connection by which one state can support/transform into another.

**Admission:** Established by admissible evidence, governing normative rule, or valid derivation.

**Not:** association, plausibility, temporal proximity, lexical similarity, typical implementation.

**Effect:** Missing relationship blocks dependent transitions.

## `TRANSITION`

**Dimension:** Reasoning operation.

**Definition:** Proposed transformation:

`T: {X1...Xn} -> P`

from identified premises to a new proposition/state.

**Admission:** Premises admissible and connecting relation valid for exact target.

**Not:** narrative continuation or plausible explanation.

**Effect:** Unsupported transition stops dependent branch.

## `VALID`

**Dimension:** Operation/rule qualification.

**Definition:** A transition, method, criterion application, or reasoning operation satisfies the exact rules governing that operation.

**Admission:** Applicable validation rule is known.

**Not:** true, useful, approved, successful, conventional.

**Effect:** Always scope `VALID` to the operation/rule set.

## `MATERIAL`

**Dimension:** Task consequence.

**Definition:** A fact, ambiguity, contradiction, or omission is material when changing/resolving it could change answer, evidence required, criterion, permitted action, recommendation, or conclusion scope/certainty.

**Admission:** Task-effect dependency is identifiable.

**Not:** merely interesting or important in general.

## `CONSEQUENTIAL`

**Dimension:** Action/decision significance.

**Definition:** An action/recommendation is consequential when relying on or executing it could alter artifact/system state, release/status, authority boundary, evidence state, project direction, or another non-trivial external condition.

**Not:** only irreversible/high-risk actions.

**Effect:** Visible care may scale; substantive authority/evidence controls do not.
