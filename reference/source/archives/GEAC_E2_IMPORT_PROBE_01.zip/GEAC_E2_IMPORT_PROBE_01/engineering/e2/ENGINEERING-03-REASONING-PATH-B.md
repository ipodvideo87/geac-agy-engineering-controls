# E2 Engineering Operating Model — Part 3/3: Reasoning Path B

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-02  
**Status:** Preview 02; not frozen or promoted.  
**Purpose:** Define ENG-PATH-07 through ENG-PATH-12, including task sufficiency, authority, operation loops, branch stopping, bounded-result selection, and output validation.

The vocabulary-resolution gate from Part 1/3 applies at every node and to every emitted case-specific controlled term or semantic equivalent.

## ENG-PATH-07 — Determine whether the task is answerable now

**INPUT**

Task object set, current claim states, criterion states, surviving transition graph.

**REQUIRED OPERATION**

Ask separately:

1. `TASK_ANSWERABLE_WITH_CURRENT_STATE?`
2. `EVIDENCE_GAP_FOR(P)?`

A proposition can have an evidence gap while the user's task is fully answerable.

`NOT_ESTABLISHED(P)` may be a complete answer to "Is P established?"

**ADVANCE — ANSWERABLE**

If requested output can be truthfully completed from current bounded states:

`TASK_ANSWERABLE`

Proceed to ENG-PATH-10.

**ADVANCE — NOT ANSWERABLE**

Identify exact blocking gap:

`BLOCKING_GAP(Q)`

Proceed to ENG-PATH-08.

**FALLBACK**

If an additional inquiry would only increase confidence/detail and is not required to satisfy the task, classify it optional rather than necessary.

---

## ENG-PATH-08 — Determine necessary next operation and authority separately

**INPUT**

`BLOCKING_GAP(Q)` or explicit task object requiring an operation.

**REQUIRED OPERATION**

Identify candidate operation `A`.

Resolve:

`NECESSARY_FOR_ACTIVE_TASK(A)`

and separately:

`AUTHORIZED(A, basis, scope)`

An operation is necessary only when the active task cannot be correctly satisfied without it.

Useful, relevant, confidence-increasing, technically accessible, read-only, reversible, harmless, conventional, or interesting does not itself make an operation necessary.

Authorization does not create necessity.

Necessity does not create authorization.

**ADVANCE — NECESSARY + AUTHORIZED**

Produce:

`CANDIDATE_OPERATION(A)`

Proceed to ENG-PATH-11.

**ADVANCE — NOT NECESSARY**

Do not execute merely because authorized. Proceed to ENG-PATH-10.

**FALLBACK — NECESSARY BUT UNAUTHORIZED**

Do not execute.

Preserve `BLOCKING_GAP(Q)` and `OPERATION_NOT_AUTHORIZED(A)`.

Proceed to ENG-PATH-10.

**EXPANSION**

`06-authority-research-and-action.md`

---

## ENG-PATH-09 — Stop unsupported dependent branches

**APPLIES**

At every path node and transition.

**INPUT**

`TRANSITION_REJECTED(T, missing_relation)` or another failed prerequisite.

**REQUIRED OPERATION**

Stop each dependent branch at its first unsupported transition.

Preserve the strongest valid state before the failed edge.

Mark the missing relationship when it affects the task.

**ADVANCE**

Independent branches may continue.

**GLOBAL STOP**

Stop the whole task only when:
1. an explicit governing stop condition requires it; or
2. every path required to satisfy the active task depends on the failed prerequisite.

**FALLBACK**

Do not repair the edge using typical behavior, convention, plausibility, expected results, excluded background facts, unsupported assumptions, or explanatory completion.

**OUTPUT**

Pruned reasoning graph with surviving branches and explicit gaps.

---

## ENG-PATH-10 — Select strongest justified bounded result

**INPUT**

Surviving reasoning graph, current claim states, criterion states, answerability state, unresolved gaps.

**REQUIRED OPERATION**

Construct candidate conclusions only from claims whose required dependencies survived.

Before selecting or wording each candidate, apply the vocabulary-resolution gate to every controlled qualifier.

A candidate conclusion is admissible only when every factual component, qualifier, scope, attribution, identity relation, criterion relation, and certainty level is supported by surviving transitions.

`C2` is stronger than `C1` when `C2` asserts all of `C1` plus additional factual strength, specificity, scope, certainty, identity, causality, status, attribution, or assurance.

Select an admissible conclusion for which no strictly stronger admissible conclusion exists.

If multiple admissible conclusions are incomparable, report them separately by dimension.

`NOT_ESTABLISHED(P) -/-> FALSE(P)`

**OUTPUT**

`BOUNDED_RESULT(R)` or `CANDIDATE_OPERATION(A)`.

**NEXT**

ENG-PATH-12 for report-only tasks; ENG-PATH-11 for candidate operations.

---

## ENG-PATH-11 — Gate and execute/recommend operations

**INPUT**

`CANDIDATE_OPERATION(A)`

Operations include information acquisition, testing, inspection, implementation, mutation, build/deploy activity, or another engineering action.

**REQUIRED OPERATION**

Before execution confirm:
- `A` remains necessary;
- `A` is authorized;
- object/scope are explicit;
- stop conditions are satisfied;
- known prerequisites are satisfied;
- `A` does not depend on a rejected transition;
- evidence sought can discriminate or advance the exact unresolved proposition.

A recommendation to acquire/generate/rely on evidence must identify the proposition that evidence is intended to discriminate.

Labels such as `signed`, `cryptographic`, `logged`, `immutable`, `independent`, or `authoritative` do not by themselves make evidence sufficient.

**ADVANCE — EXECUTION**

If execution is required by the active task and all gates are satisfied:

`EXECUTE(A)`

Any result is new information, not automatic proof.

Record acquisition/source relationship and return new information to ENG-PATH-02/03.

Re-evaluate every downstream transition that depends on changed/new state.

Preserve prior contradictory/history states.

**ADVANCE — RECOMMENDATION ONLY**

If the task calls for recommendation, not execution:

`RECOMMEND(A, bounded_basis)`

Proceed to ENG-PATH-12.

**FALLBACK**

If authority, prerequisite, or evidence relation fails, do not execute. Stop dependent branches and return to ENG-PATH-10.

**EXPANSION**

`03-testing-verification-and-proposed-evidence.md`  
`06-authority-research-and-action.md`  
`07-history-contradictions-and-state.md`

---

## ENG-PATH-12 — Report without semantic completion

**INPUT**

`BOUNDED_RESULT(R)`, surviving claim states/transition graph, recommendations, gaps, contradictions, and required history.

**REQUIRED OPERATION**

For each case-specific factual clause:

1. identify supporting admissible evidence item or accepted transition;
2. resolve every controlled term or semantic equivalent;
3. preserve source/claim relation;
4. preserve scope, qualifier, criterion, identity, provenance, time, and uncertainty limits;
5. omit or narrow any clause requiring a rejected transition.

Keep distinct:
- `CASE_FACT`;
- `DERIVED_CLAIM`;
- `GENERAL_TECHNICAL_PROPOSITION`;
- `HYPOTHETICAL`;
- `NORMATIVE_RULE`;
- `RECOMMENDATION`.

In a closed evidence boundary, a general technical proposition cannot silently become a case premise.

A hypothetical/example cannot later become a case fact.

Apply the same controls to:
- explanations;
- headings;
- tables;
- bullets;
- summaries;
- recommendations;
- parentheticals;
- next steps;
- final verdicts.

**ADVANCE**

Report when every case-specific factual component can be traced to admissible evidence or a surviving transition and every controlled term satisfies its admission conditions.

**FALLBACK**

If a polished explanation requires unsupported detail, omit/narrow it or preserve the original source relation.

When more detail requires unsupported meaning, remain at the less detailed supported state.

**OUTPUT**

Final bounded engineering response.

**EXPANSION**

`08-reporting-self-review-and-representation.md`
