# E2 Controlled Engineering Vocabulary — Part 2/4: Epistemic and Source States

**Contract:** GEAC-2026-08-15-V1.1-E2-PREVIEW-02  
**Status:** Preview 02; not frozen or promoted.

## `SUPPLIED(X)`

**Definition:** `X` was present in permitted task input or allowed source material.

**Not:** true, independently observed, verified, current, complete, authoritative.

## `ACQUIRED(X, method, scope)`

**Definition:** `X` was obtained through an operation performed within allowed scope.

**Not:** automatically true or sufficient.

## `NOT_SUPPLIED(X)`

**Definition:** Allowed evidence set does not contain `X`.

**Not:** `NOT_PERFORMED(X)`, `DOES_NOT_EXIST(X)`, `FALSE(X)`, `NEVER_OCCURRED(X)`.

## `REPORTS(S,P)`

**Definition:** Source/representation `S` reports proposition `P`.

**Not:** proposition `P` itself.

`REPORTS(S,P) -/-> ESTABLISHED(P)`

## `ASSERTS(S,P)`

**Definition:** Source `S` asserts proposition `P`.

**Not:** establishment or observation of external reality.

## `ATTESTS(S,P)`

**Definition:** Source `S` declares/vouches for proposition `P`.

**Not:** proof, independent observation, truth.

`ATTESTS(S,P) -/-> ESTABLISHED(P)`

## `STATUS_ASSERTION(label,P)`

**Definition:** Source applies status label `label` to `P`.

`STATUS_ASSERTION("VERIFIED",P) -/-> VERIFIED(P)`

## `EXPECTED_VALUE(S,V)`

**Definition:** Source `S` specifies `V` as expected, intended, configured, predicted, or target value.

`EXPECTED_VALUE(S,V) -/-> ACTUAL_VALUE(object,V)`

## `OBSERVATION`

**Definition:** Direct encounter with a representation or object through an identified observation method.

**Admission:** Observed thing and method identifiable.

**Not:** verification, truth of everything represented, causality, broad provenance.

## `OBSERVED_REPRESENTATION(R)`

**Definition:** Representation `R` itself was directly observed.

**Not:** external event/state described by `R`.

## `OBSERVED_OBJECT(O)`

**Definition:** Relevant object/state `O` was directly observed through an identified method.

**Effect:** Bound to method, scope, time, environment.

## `OBSERVED_RESULT(R)`

**Definition:** Result representation `R` was directly observed.

**Not:** mechanism, oracle, coverage, correctness.

## `ESTABLISHED(P,basis)`

**Definition:** Admissible evidence and accepted transitions are sufficient for exact bounded proposition `P`; every factual component/qualifier is supported by surviving dependencies.

**Admission:** No required unsupported transition remains between premises and `P`.

**Not:** reported, asserted, expected, plausible, likely, verified-by-label.

**Effect:** May be reported as factual conclusion only within exact bound.

## `NOT_ESTABLISHED(P,reason)`

**Definition:** Current admissible evidence and surviving transitions do not support `ESTABLISHED(P)`.

**Not:** false, disproven, absent, failed, not performed, impossible.

## `INCONCLUSIVE(P,reason)`

**Definition:** Current evidence cannot resolve `P` to level required by task, often because evidence conflicts or does not discriminate.

**Not:** necessarily false or completely unsupported.

## `CONTRADICTED(P,evidence)`

**Definition:** Admissible evidence conflicts with `P` or a prerequisite required to support it.

**Effect:** Contradiction remains explicit until resolved by discriminating evidence.

## `DERIVED(P,premises,rule)`

**Definition:** `P` follows through an accepted transition from identified admissible premises.

**Admission:** premises and relationship identified and valid.

**Effect:** Inherits scope/dependency limits of premises.

## `INFERRED(P,basis)`

**Definition:** Explicit reasoned interpretation from identified premises that is not independently observed.

**Admission:** Factual premises admissible and inferential relation valid.

**Not:** permission to import outside facts or guess a mechanism.

## `ASSUMPTION(A)`

**Definition:** Proposition temporarily introduced for conditional reasoning without being treated as established fact.

**Admission:** Explicit, task-permitted, dependency remains visible.

**Effect:** Dependent conclusion remains conditional.

## `EXPECTED_ONLY(P,basis)`

**Definition:** `P` is expected/intended/configured/predicted but not established actual.

## `UNKNOWN(X)`

**Definition:** Value/state/relationship has not been established within current admissible evidence.

**Not:** false, absent, unknowable, not performed, irrelevant.

## `NOT_TESTED(P)`

**Definition:** No admissible test evidence sufficient to evaluate `P` has been established for required object/scope/time.

**Not:** failed.

## `VERIFIED(P,method,evidence,criterion,scope)`

**Definition:** Specialized established state where a defined verification method evaluated exact proposition `P` against an applicable criterion using identified evidence and scope.

**Admission requires all:**
1. exact proposition;
2. exact object/scope;
3. verification method;
4. produced/observed evidence;
5. applicable verification criterion;
6. evaluation result.

**Not:** source says "verified", tests passed, observed, informally checked, likely correct.

## `INDEPENDENT(E1,E2,failure_mode)`

**Definition:** Established separation between evidence/checks relevant to the failure mode under evaluation.

**Not:** different command, run, file, attempt, paragraph, label, or repeated check by same dependency chain.

## `INDEPENDENTLY_VERIFIED(P,verification,independence_relation)`

**Definition:** `VERIFIED(P,...)` plus established `INDEPENDENT(...)` relation relevant to the guarded failure mode.

## Epistemic Non-Equivalences

`SUPPLIED(P) != OBSERVED_OBJECT(P)`  
`SUPPLIED(P) != VERIFIED(P)`  
`OBSERVED_REPRESENTATION(P) != OBSERVED_OBJECT(P)`  
`REPORTS(S,P) != ESTABLISHED(P)`  
`ATTESTS(S,P) != ESTABLISHED(P)`  
`NOT_SUPPLIED(P) != NOT_PERFORMED(P)`  
`NOT_ESTABLISHED(P) != FALSE(P)`  
`NOT_TESTED(P) != FAILED(P)`  
`EXPECTED_ONLY(P) != ESTABLISHED(P)`

<!-- TEMPORARY IMPORT PROBE; NON-NORMATIVE -->
GEAC_IMPORT_PROBE_VOCAB=C8386A620E150EBA326DA5436A767A63
