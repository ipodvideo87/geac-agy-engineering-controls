# GEAC E2 Preview 02

**Contract ID:** `GEAC-2026-08-15-V1.1-E2-PREVIEW-02`

This package is a design/behavioral preview. It is not frozen or promoted.

## Preview-02 changes

1. Splits the oversized `ENGINEERING.md` into three semantic parts.
2. Splits the oversized vocabulary into four semantic parts.
3. Keeps every normative `.md` file below the 13,000-character design ceiling.
4. Targets roughly 9,000–11,000 characters or less per normative file where practical.
5. Adds a mandatory Vocabulary Resolution Gate.
6. Distinguishes lexical/source use of a controlled word from instantiation of the controlled engineering state.
7. Applies vocabulary resolution at source interpretation, state assignment, transition evaluation, status/authority evaluation, and output generation.
8. Imports every normative E2 file directly from `GEMINI.md` so the preview does not depend on recursive nested imports for file presence.
9. Preserves the nine specialized expansion modules as separate files and binds them to the vocabulary gate.

## Architecture

```text
GEMINI.md
  -> ENGINEERING-01-CORE.md
  -> ENGINEERING-02-REASONING-PATH-A.md
  -> ENGINEERING-03-REASONING-PATH-B.md

  -> 00-vocabulary-01-foundations.md
  -> 00-vocabulary-02-epistemic.md
  -> 00-vocabulary-03-criteria-authority.md
  -> 00-vocabulary-04-identity-history-reporting.md

  -> 01-evidence-states-and-source-semantics.md
  -> 02-semantic-transitions-and-derivation.md
  -> 03-testing-verification-and-proposed-evidence.md
  -> 04-identity-provenance-and-time.md
  -> 05-criteria-status-and-completion.md
  -> 06-authority-research-and-action.md
  -> 07-history-contradictions-and-state.md
  -> 08-reporting-self-review-and-representation.md
  -> 09-control-effectiveness-and-behavioral-validation.md
```

## Important caveat

The 13,000-character value is used here as an E2 design ceiling. This package does not claim that 13,000 characters has been established as a specific Antigravity host/runtime hard limit.

The purpose is to remove oversized-file risk while leaving room for later evidence about actual host limits.
