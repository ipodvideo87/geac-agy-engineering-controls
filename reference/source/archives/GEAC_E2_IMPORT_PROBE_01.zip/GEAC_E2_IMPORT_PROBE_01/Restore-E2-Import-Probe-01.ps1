param(
    [Parameter(Mandatory=$true)]
    [string]$Backup
)

$ErrorActionPreference = "Stop"
$GeminiRoot = "$env:USERPROFILE\.gemini"
$InstalledE2 = "$GeminiRoot\engineering\e2"

if (-not (Test-Path -LiteralPath "$Backup\GEMINI.md")) {
    throw "Backup GEMINI.md missing: $Backup"
}
if (-not (Test-Path -LiteralPath "$Backup\e2")) {
    throw "Backup e2 directory missing: $Backup"
}

if (Test-Path -LiteralPath $InstalledE2) {
    Remove-Item -LiteralPath $InstalledE2 -Recurse -Force
}

New-Item -ItemType Directory -Path $InstalledE2 -Force | Out-Null
Copy-Item -Path "$Backup\e2\*" -Destination $InstalledE2 -Recurse -Force
Copy-Item -LiteralPath "$Backup\GEMINI.md" -Destination "$GeminiRoot\GEMINI.md" -Force

Write-Host "PRE-PROBE STATE RESTORED" -ForegroundColor Green
Write-Host "Re-run the Preview-02 hash verification before further behavioral tests."
